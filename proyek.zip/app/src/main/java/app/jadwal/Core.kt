package app.jadwal

import android.app.*
import android.content.*
import android.media.AudioAttributes
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

data class Item(val id: Long, val title: String, val hour: Int, val minute: Int, val days: Int, val date: Long, val alarm: Boolean, val on: Boolean)

object Store {
    private fun p(c: Context) = c.getSharedPreferences("jadwal", Context.MODE_PRIVATE)
    fun all(c: Context): List<Item> {
        val a = JSONArray(p(c).getString("items", "[]"))
        return (0 until a.length()).map { k ->
            val o = a.getJSONObject(k)
            Item(o.getLong("id"), o.getString("title"), o.getInt("h"), o.getInt("m"), o.getInt("d"), o.getLong("dt"), o.getBoolean("al"), o.getBoolean("on"))
        }
    }
    fun save(c: Context, l: List<Item>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("title", it.title).put("h", it.hour).put("m", it.minute).put("d", it.days).put("dt", it.date).put("al", it.alarm).put("on", it.on)) }
        p(c).edit().putString("items", a.toString()).apply()
    }
    fun get(c: Context, id: Long): Item? = all(c).firstOrNull { it.id == id }
}

object Sched {
    fun next(i: Item, from: Long = System.currentTimeMillis()): Long {
        val c = Calendar.getInstance()
        if (i.date > 0) c.timeInMillis = i.date else c.timeInMillis = from
        c.set(Calendar.HOUR_OF_DAY, i.hour); c.set(Calendar.MINUTE, i.minute); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        if (i.date > 0) return if (c.timeInMillis > from) c.timeInMillis else -1L
        repeat(8) {
            val dow = c.get(Calendar.DAY_OF_WEEK) - 1
            if (c.timeInMillis > from && (i.days == 0 || ((i.days shr dow) and 1) == 1)) return c.timeInMillis
            c.add(Calendar.DAY_OF_YEAR, 1)
        }
        return -1L
    }
    private fun pi(c: Context, id: Long): PendingIntent =
        PendingIntent.getBroadcast(c, id.toInt(), Intent(c, AlarmReceiver::class.java).putExtra("id", id), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    private fun at(c: Context, id: Long, t: Long) {
        val show = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        c.getSystemService(AlarmManager::class.java).setAlarmClock(AlarmManager.AlarmClockInfo(t, show), pi(c, id))
    }
    fun set(c: Context, i: Item) {
        cancel(c, i.id)
        if (!i.on) return
        val t = next(i)
        if (t > 0) at(c, i.id, t)
    }
    fun cancel(c: Context, id: Long) { c.getSystemService(AlarmManager::class.java).cancel(pi(c, id)) }
    fun snooze(c: Context, id: Long, min: Int) { at(c, id, System.currentTimeMillis() + min * 60000L) }
}

object Notif {
    fun channels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("pengingat", "Pengingat", NotificationManager.IMPORTANCE_HIGH))
        val al = NotificationChannel("alarm", "Alarm", NotificationManager.IMPORTANCE_HIGH)
        al.setSound(Settings.System.DEFAULT_ALARM_ALERT_URI, AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
        al.enableVibration(true)
        nm.createNotificationChannel(al)
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getLongExtra("id", 0L)
        val nm = c.getSystemService(NotificationManager::class.java)
        if (i.action == "DONE") { nm.cancel(id.toInt()); return }
        if (i.action == "SNOOZE") { nm.cancel(id.toInt()); Sched.snooze(c, id, 10); return }
        val x = Store.get(c, id) ?: return
        if (x.days == 0) Store.save(c, Store.all(c).map { if (it.id == id) it.copy(on = false) else it }) else Sched.set(c, x)
        Notif.channels(c)
        val f = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        fun act(a: String) = PendingIntent.getBroadcast(c, id.toInt(), Intent(c, AlarmReceiver::class.java).setAction(a).putExtra("id", id), f)
        val b = Notification.Builder(c, if (x.alarm) "alarm" else "pengingat")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(x.title)
            .setContentText("%02d.%02d".format(x.hour, x.minute))
            .setAutoCancel(true)
            .addAction(Notification.Action.Builder(0, "Selesai", act("DONE")).build())
            .addAction(Notification.Action.Builder(0, "Tunda 10 mnt", act("SNOOZE")).build())
        if (x.alarm) b.setFullScreenIntent(PendingIntent.getActivity(c, id.toInt(), Intent(c, AlarmActivity::class.java).putExtra("id", id).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), f), true)
        val n = b.build()
        if (x.alarm) n.flags = n.flags or Notification.FLAG_INSISTENT
        nm.notify(id.toInt(), n)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { Store.all(c).forEach { Sched.set(c, it) } }
}

object Parser {
    private val tm = Regex("""(?:jam|pukul)\s*(\d{1,2})(?:[.:](\d{2}))?""", RegexOption.IGNORE_CASE)
    private val dur = Regex("""(?:sampai|hingga|selama)\s*(?:jam|pukul)?\s*\d+(?:[.:]\d{2})?\s*(?:jam|menit)?|\d+\s*(?:jam|menit)""", RegexOption.IGNORE_CASE)
    private val junk = Regex("""\b(?:besok|lusa|hari ini|pagi|siang|sore|malam|nanti|saya|aku)\b""", RegexOption.IGNORE_CASE)
    fun parse(text: String): List<Item> {
        val low = text.lowercase()
        val off = if ("lusa" in low) 2 else if ("besok" in low) 1 else 0
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, off)
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        val base = System.currentTimeMillis() % 1_000_000_000L
        val out = mutableListOf<Item>()
        for (seg in text.split(Regex("""[,;\n]|\blalu\b|\bkemudian\b""", RegexOption.IGNORE_CASE))) {
            val s = seg.lowercase()
            val m = tm.find(s)
            var h: Int
            var mn = 0
            if (m != null) {
                h = m.groupValues[1].toInt()
                mn = m.groupValues[2].toIntOrNull() ?: 0
                if (h < 12 && ("malam" in s || "sore" in s || ("siang" in s && h < 7))) h += 12
            } else {
                h = if ("malam" in s) 19 else if ("sore" in s) 16 else if ("siang" in s) 12 else if ("pagi" in s) 7 else -1
            }
            if (h < 0 || h > 23 || mn > 59) continue
            val title = s.replace(tm, "").replace(dur, "").replace(junk, "").replace(Regex("""\s+"""), " ").trim().replaceFirstChar { it.uppercase() }
            if (title.isEmpty()) continue
            out.add(Item(base + out.size, title, h, mn, 0, if (off > 0) cal.timeInMillis else 0L, true, true))
        }
        return out
    }
}

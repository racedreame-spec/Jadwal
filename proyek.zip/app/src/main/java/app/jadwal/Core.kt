package app.jadwal

import android.app.*
import android.content.*
import android.media.AudioAttributes
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

data class Item(val id: Long, val title: String, val hour: Int, val minute: Int, val days: Int, val date: Long, val alarm: Boolean, val on: Boolean, val grp: String = "Umum")

object Store {
    private fun p(c: Context) = c.getSharedPreferences("jadwal", Context.MODE_PRIVATE)
    fun all(c: Context): List<Item> {
        val a = JSONArray(p(c).getString("items", "[]"))
        return (0 until a.length()).map { k ->
            val o = a.getJSONObject(k)
            Item(o.getLong("id"), o.getString("title"), o.getInt("h"), o.getInt("m"), o.getInt("d"), o.getLong("dt"), o.getBoolean("al"), o.getBoolean("on"), o.optString("g", "Umum"))
        }
    }
    fun save(c: Context, l: List<Item>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("title", it.title).put("h", it.hour).put("m", it.minute).put("d", it.days).put("dt", it.date).put("al", it.alarm).put("on", it.on).put("g", it.grp)) }
        p(c).edit().putString("items", a.toString()).apply()
    }
    fun get(c: Context, id: Long): Item? = all(c).firstOrNull { it.id == id }
}

object Sched {
    fun next(i: Item, from: Long = System.currentTimeMillis()): Long {
        val c = Calendar.getInstance()
        if (i.date > 0) c.timeInMillis = i.date else c.timeInMillis = from
        c.set(Calendar.HOUR_OF_DAY, i.hour); c.set(Calendar.MINUTE, i.minute); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        if (i.date > 0) return if (c.timeInMillis > from) c.timeInMillis else -1L
        repeat(8) {
            val dow = c.get(Calendar.DAY_OF_WEEK) - 1
            if (c.timeInMillis > from && (i.days == 0 || ((i.days shr dow) and 1) == 1)) return c.timeInMillis
            c.add(Calendar.DAY_OF_YEAR, 1)
        }
        return -1L
    }
    private fun pi(c: Context, id: Long): PendingIntent =
        PendingIntent.getBroadcast(c, id.toInt(), Intent(c, AlarmReceiver::class.java).putExtra("id", id), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    private fun at(c: Context, id: Long, t: Long) {
        val show = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        c.getSystemService(AlarmManager::class.java).setAlarmClock(AlarmManager.AlarmClockInfo(t, show), pi(c, id))
    }
    fun set(c: Context, i: Item) {
        cancel(c, i.id)
        if (!i.on) return
        val t = next(i)
        if (t > 0) at(c, i.id, t)
    }
    fun cancel(c: Context, id: Long) { c.getSystemService(AlarmManager::class.java).cancel(pi(c, id)) }
    fun snooze(c: Context, id: Long, min: Int) { at(c, id, System.currentTimeMillis() + min * 60000L) }
    private fun tpi(c: Context): PendingIntent =
        PendingIntent.getBroadcast(c, 424242, Intent(c, AlarmReceiver::class.java).putExtra("id", -1L), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    fun timerAt(c: Context, t: Long) {
        val show = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        c.getSystemService(AlarmManager::class.java).setAlarmClock(AlarmManager.AlarmClockInfo(t, show), tpi(c))
    }
    fun timerCancel(c: Context) { c.getSystemService(AlarmManager::class.java).cancel(tpi(c)) }
}

object Notif {
    fun channels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("pengingat", "Pengingat", NotificationManager.IMPORTANCE_HIGH))
        val al = NotificationChannel("alarm", "Alarm", NotificationManager.IMPORTANCE_HIGH)
        al.setSound(Settings.System.DEFAULT_ALARM_ALERT_URI, AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
        al.enableVibration(true)
        nm.createNotificationChannel(al)
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getLongExtra("id", 0L)
        val nm = c.getSystemService(NotificationManager::class.java)
        if (i.action == "DONE") { nm.cancel(id.toInt()); Store.get(c, id)?.let { Hist.mark(c, it) }; return }
        if (i.action == "SNOOZE") { nm.cancel(id.toInt()); Sched.snooze(c, id, 10); return }
        if (id == -1L) {
            TimerStore.finish(c)
            Notif.channels(c)
            val tn = Notification.Builder(c, "alarm").setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("Timer selesai").setContentText("Waktu fokus Anda sudah habis.").setAutoCancel(true)
                .setContentIntent(PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)).build()
            tn.flags = tn.flags or Notification.FLAG_INSISTENT
            nm.notify(999999, tn)
            return
        }
        val x = Store.get(c, id) ?: return
        if (x.days == 0) Store.save(c, Store.all(c).map { if (it.id == id) it.copy(on = false) else it }) else Sched.set(c, x)
        Notif.channels(c)
        val f = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        fun act(a: String) = PendingIntent.getBroadcast(c, id.toInt(), Intent(c, AlarmReceiver::class.java).setAction(a).putExtra("id", id), f)
        val b = Notification.Builder(c, if (x.alarm) "alarm" else "pengingat")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(x.title)
            .setContentText("%02d.%02d".format(x.hour, x.minute))
            .setAutoCancel(true)
            .addAction(Notification.Action.Builder(0, "Selesai", act("DONE")).build())
            .addAction(Notification.Action.Builder(0, "Tunda 10 mnt", act("SNOOZE")).build())
        if (x.alarm) b.setFullScreenIntent(PendingIntent.getActivity(c, id.toInt(), Intent(c, AlarmActivity::class.java).putExtra("id", id).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), f), true)
        val n = b.build()
        if (x.alarm) n.flags = n.flags or Notification.FLAG_INSISTENT
        nm.notify(id.toInt(), n)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { Store.all(c).forEach { Sched.set(c, it) } }
}

object Parser {
    private val tm = Regex("""(?:jam|pukul)\s*(\d{1,2})(?:[.:](\d{2}))?""", RegexOption.IGNORE_CASE)
    private val dur = Regex("""(?:sampai|hingga|selama)\s*(?:jam|pukul)?\s*\d+(?:[.:]\d{2})?\s*(?:jam|menit)?|\d+\s*(?:jam|menit)""", RegexOption.IGNORE_CASE)
    private val junk = Regex("""\b(?:besok|lusa|hari ini|pagi|siang|sore|malam|nanti|saya|aku)\b""", RegexOption.IGNORE_CASE)
    fun parse(text: String): List<Item> {
        val low = text.lowercase()
        val off = if ("lusa" in low) 2 else if ("besok" in low) 1 else 0
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, off)
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        val base = System.currentTimeMillis() % 1_000_000_000L
        val out = mutableListOf<Item>()
        for (seg in text.split(Regex("""[,;\n]|\blalu\b|\bkemudian\b""", RegexOption.IGNORE_CASE))) {
            val s = seg.lowercase()
            val m = tm.find(s)
            var h: Int
            var mn = 0
            if (m != null) {
                h = m.groupValues[1].toInt()
                mn = m.groupValues[2].toIntOrNull() ?: 0
                if (h < 12 && ("malam" in s || "sore" in s || ("siang" in s && h < 7))) h += 12
            } else {
                h = if ("malam" in s) 19 else if ("sore" in s) 16 else if ("siang" in s) 12 else if ("pagi" in s) 7 else -1
            }
            if (h < 0 || h > 23 || mn > 59) continue
            val title = s.replace(tm, "").replace(dur, "").replace(junk, "").replace(Regex("""\s+"""), " ").trim().replaceFirstChar { it.uppercase() }
            if (title.isEmpty()) continue
            out.add(Item(base + out.size, title, h, mn, 0, if (off > 0) cal.timeInMillis else 0L, true, true))
        }
        return out
    }
}

data class Rec(val d: String, val id: Long, val g: String)

object Hist {
    private fun p(c: Context) = c.getSharedPreferences("log", Context.MODE_PRIVATE)
    fun day(t: Long = System.currentTimeMillis()): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(t))
    fun all(c: Context): List<Rec> {
        val a = JSONArray(p(c).getString("l", "[]"))
        return (0 until a.length()).map { val o = a.getJSONObject(it); Rec(o.getString("d"), o.getLong("id"), o.getString("g")) }
    }
    private fun save(c: Context, l: List<Rec>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("d", it.d).put("id", it.id).put("g", it.g)) }
        p(c).edit().putString("l", a.toString()).apply()
    }
    fun isDone(c: Context, id: Long, d: String = day()): Boolean = all(c).any { it.d == d && it.id == id }
    fun mark(c: Context, x: Item) { if (!isDone(c, x.id)) save(c, all(c) + Rec(day(), x.id, x.grp)) }
    fun toggle(c: Context, x: Item) {
        if (isDone(c, x.id)) save(c, all(c).filterNot { it.d == day() && it.id == x.id }) else mark(c, x)
    }
    fun streak(c: Context): Int {
        val days = all(c).map { it.d }.toSet()
        var n = 0
        val cal = Calendar.getInstance()
        if (day(cal.timeInMillis) !in days) cal.add(Calendar.DAY_OF_YEAR, -1)
        while (day(cal.timeInMillis) in days) { n++; cal.add(Calendar.DAY_OF_YEAR, -1) }
        return n
    }
}

object Groups {
    private fun p(c: Context) = c.getSharedPreferences("grp", Context.MODE_PRIVATE)
    fun all(c: Context): List<String> {
        val a = JSONArray(p(c).getString("g", "[\"Umum\",\"Kuliah\",\"Ibadah\",\"Pelayanan\",\"Belajar\",\"Olahraga\",\"Pribadi\"]"))
        return (0 until a.length()).map { a.getString(it) }
    }
    fun save(c: Context, l: List<String>) { p(c).edit().putString("g", JSONArray(l).toString()).apply() }
    private val pal = intArrayOf(0xFF94A3B8.toInt(), 0xFF60A5FA.toInt(), 0xFFC4B5FD.toInt(), 0xFFFBBF24.toInt(), 0xFF67E8F9.toInt(), 0xFF34D399.toInt(), 0xFFF9A8D4.toInt(), 0xFFFB923C.toInt())
    fun color(c: Context, g: String): Int = pal[all(c).indexOf(g).coerceAtLeast(0) % pal.size]
}

data class Jr(val id: Long, val t: Long, val mood: String, val text: String)

object Jrn {
    private fun p(c: Context) = c.getSharedPreferences("jr", Context.MODE_PRIVATE)
    fun all(c: Context): List<Jr> {
        val a = JSONArray(p(c).getString("j", "[]"))
        return (0 until a.length()).map { val o = a.getJSONObject(it); Jr(o.getLong("id"), o.getLong("t"), o.getString("m"), o.getString("x")) }.sortedByDescending { it.t }
    }
    fun save(c: Context, l: List<Jr>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("t", it.t).put("m", it.mood).put("x", it.text)) }
        p(c).edit().putString("j", a.toString()).apply()
    }
}

object TimerStore {
    private fun p(c: Context) = c.getSharedPreferences("timer", Context.MODE_PRIVATE)
    fun end(c: Context): Long = p(c).getLong("end", 0L)
    fun start(c: Context, min: Int, link: Long) {
        val e = System.currentTimeMillis() + min * 60000L
        p(c).edit().putLong("end", e).putLong("link", link).putInt("min", min).apply()
        Sched.timerAt(c, e)
    }
    fun cancel(c: Context) { p(c).edit().putLong("end", 0L).apply(); Sched.timerCancel(c) }
    fun finish(c: Context) {
        val pr = p(c)
        val l = pr.getLong("link", 0L)
        if (l != 0L) Store.get(c, l)?.let { Hist.mark(c, it) }
        val a = JSONArray(pr.getString("s", "[]"))
        a.put(JSONObject().put("d", Hist.day()).put("m", pr.getInt("min", 0)))
        pr.edit().putString("s", a.toString()).putLong("end", 0L).apply()
    }
    fun minutesToday(c: Context): Int {
        val a = JSONArray(p(c).getString("s", "[]"))
        val d = Hist.day()
        var t = 0
        for (k in 0 until a.length()) { val o = a.getJSONObject(k); if (o.getString("d") == d) t += o.getInt("m") }
        return t
    }
}

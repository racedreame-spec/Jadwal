package app.jadwal

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.text.InputType
import android.text.Editable
import android.text.TextWatcher
import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import java.io.File
import android.view.Gravity
import android.view.View
import android.view.MotionEvent
import android.view.animation.LinearInterpolator
import android.graphics.drawable.Drawable
import android.view.animation.Animation
import android.view.animation.DecelerateInterpolator
import android.view.animation.ScaleAnimation
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

private val BG = 0xFF14161A.toInt()
private val FG = 0xFFE8EAED.toInt()
private val MU = 0xFF9AA0A8.toInt()
private val YEL = 0xFFFFC400.toInt()
private val CY = YEL
private val GR = intArrayOf(0xFFFFC400.toInt(), 0xFFFFC400.toInt())

class Ring(c: Context) : View(c) {
    private var shown = 0f
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 24f; color = 0x1FFFFFFF }
    private val fg = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 24f; strokeCap = Paint.Cap.ROUND; color = 0xFFFFC400.toInt() }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; textSize = 48f; typeface = Typeface.DEFAULT_BOLD }
    fun go(t: Float) {
        ValueAnimator.ofFloat(0f, t).apply {
            duration = 1200
            interpolator = DecelerateInterpolator()
            addUpdateListener { shown = it.animatedValue as Float; invalidate() }
        }.start()
    }
    override fun onDraw(cv: Canvas) {
        val r = RectF(20f, 20f, width - 20f, height - 20f)
        cv.drawArc(r, 0f, 360f, false, bg)
        cv.drawArc(r, -90f, 360f * shown, false, fg)
        cv.drawText("${(shown * 100).toInt()}%", width / 2f, height / 2f + 16f, tp)
    }
}

class LL(val f: (Location) -> Unit) : LocationListener {
    override fun onLocationChanged(l: Location) { f(l) }
    override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
    override fun onProviderEnabled(p: String) {}
    override fun onProviderDisabled(p: String) {}
}

class Plate(private val fill: Int, private val line: Int, private val cut: Float) : Drawable() {
    private val pf = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val pl = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f }
    override fun draw(c: Canvas) {
        val b = bounds
        val p = Path()
        p.moveTo(b.left + 1f, b.top + 1f)
        p.lineTo(b.right - cut, b.top + 1f)
        p.lineTo(b.right - 1f, b.top + cut)
        p.lineTo(b.right - 1f, b.bottom - 1f)
        p.lineTo(b.left + 1f, b.bottom - 1f)
        p.close()
        pf.color = fill; pl.color = line
        c.drawPath(p, pf); c.drawPath(p, pl)
    }
    override fun setAlpha(a: Int) {}
    override fun setColorFilter(f: ColorFilter?) {}
    @Suppress("DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

class Grid(c: Context) : View(c) {
    private val p = Paint().apply { color = 0x0FFFFFFF; strokeWidth = 1f }
    override fun onDraw(cv: Canvas) {
        var x = 0f
        while (x < width) { cv.drawLine(x, 0f, x, height.toFloat(), p); x += 56f }
        var y = 0f
        while (y < height) { cv.drawLine(0f, y, width.toFloat(), y, p); y += 56f }
    }
}

class Belt(c: Context) : View(c) {
    private val p = Paint().apply { color = 0xFFFFC400.toInt(); style = Paint.Style.FILL }
    private var sh = 0f
    private val an = ValueAnimator.ofFloat(0f, 40f).apply {
        duration = 900; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { sh = it.animatedValue as Float; invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); an.start() }
    override fun onDetachedFromWindow() { an.cancel(); super.onDetachedFromWindow() }
    override fun onDraw(cv: Canvas) {
        val h = height.toFloat()
        var x = -h * 2 + sh
        while (x < width) {
            val pa = Path()
            pa.moveTo(x, h); pa.lineTo(x + h, 0f); pa.lineTo(x + h + 20f, 0f); pa.lineTo(x + 20f, h); pa.close()
            cv.drawPath(pa, p)
            x += 40f
        }
    }
}

class Rain(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.MONOSPACE; textSize = 26f }
    private val ch = "01{}();=<>/#abcdef"
    private val rnd = java.util.Random(7)
    private var off = FloatArray(0)
    private var spd = FloatArray(0)
    private val an = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); an.start() }
    override fun onDetachedFromWindow() { an.cancel(); super.onDetachedFromWindow() }
    override fun onDraw(cv: Canvas) {
        val cw = 38f
        val n = (width / cw).toInt()
        if (off.size != n) { off = FloatArray(n) { rnd.nextFloat() * 2000f }; spd = FloatArray(n) { 50f + rnd.nextFloat() * 110f } }
        val t = System.nanoTime() / 1_000_000_000f
        val span = height + 500f
        for (i in 0 until n) {
            val y0 = (off[i] + t * spd[i]) % span
            for (k in 0..9) {
                val y = y0 - k * 30f - 100f
                if (y < 0f || y > height) continue
                p.color = ((0x2A * (10 - k) / 10) shl 24) or 0x00FFC400
                cv.drawText(ch[(i * 7 + k + (t * 2).toInt()) % ch.length].toString(), i * cw + 6f, y, p)
            }
        }
    }
}

class Term(c: Context) : TextView(c) {
    private val hd = android.os.Handler(android.os.Looper.getMainLooper())
    private var all = listOf<String>()
    private var li = 0
    private var ci = 0
    private var alive = false
    private val shown = mutableListOf<String>()
    private val r = object : Runnable {
        override fun run() {
            if (!alive) return
            if (li >= all.size) {
                render("")
                hd.postDelayed({ if (alive) { li = 0; ci = 0; shown.clear(); hd.post(this) } }, 2500)
                return
            }
            val line = all[li]
            if (ci < line.length) { ci++; render(line.substring(0, ci)); hd.postDelayed(this, 24) }
            else { shown.add(line); li++; ci = 0; hd.postDelayed(this, 240) }
        }
    }
    init { typeface = Typeface.MONOSPACE; textSize = 10.5f; setTextColor(0xFF3DDC84.toInt()); minLines = 8; maxLines = 8 }
    private fun render(cur: String) { text = (shown.takeLast(7) + (cur + "_")).joinToString("\n") }
    fun start(l: List<String>) { all = l; li = 0; ci = 0; shown.clear(); alive = true; hd.removeCallbacksAndMessages(null); hd.post(r) }
    override fun onDetachedFromWindow() { alive = false; hd.removeCallbacksAndMessages(null); super.onDetachedFromWindow() }
}

class RouteMap(c: Context) : View(c) {
    private var routes: List<List<Pair<Double, Double>>> = emptyList()
    private var frac = 1f
    private val grid = Paint().apply { color = 0x14FFFFFF; strokeWidth = 1f }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFC400.toInt(); style = Paint.Style.STROKE; strokeWidth = 7f; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val dim = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x66FFC400; style = Paint.Style.STROKE; strokeWidth = 4f; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val fp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val num = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF14161A.toInt(); textSize = 22f; typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD); textAlign = Paint.Align.CENTER }
    private var marks: List<Pair<Double, Double>> = emptyList()
    private var hi = -1
    fun setMarks(m: List<Pair<Double, Double>>, h: Int) { marks = m; hi = h; invalidate() }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF9AA0A8.toInt(); textSize = 24f; typeface = Typeface.MONOSPACE }
    private val an = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2600; interpolator = DecelerateInterpolator()
        addUpdateListener { frac = it.animatedValue as Float; invalidate() }
    }
    fun set(rs: List<List<Pair<Double, Double>>>) { routes = rs; an.cancel(); an.start() }
    override fun onDetachedFromWindow() { an.cancel(); super.onDetachedFromWindow() }
    override fun onDraw(cv: Canvas) {
        var gx = 0f
        while (gx < width) { cv.drawLine(gx, 0f, gx, height.toFloat(), grid); gx += 48f }
        var gy = 0f
        while (gy < height) { cv.drawLine(0f, gy, width.toFloat(), gy, grid); gy += 48f }
        val all = routes.flatten() + marks
        if (all.isEmpty()) { cv.drawText("TIDAK ADA DATA RUTE", 24f, height / 2f, txt); return }
        val minLa = all.minOf { it.first }; val maxLa = all.maxOf { it.first }
        val minLo = all.minOf { it.second }; val maxLo = all.maxOf { it.second }
        val cosL = Math.cos(Math.toRadians((minLa + maxLa) / 2))
        val w = ((maxLo - minLo) * cosL).coerceAtLeast(1e-6)
        val h = (maxLa - minLa).coerceAtLeast(1e-6)
        val pad = 44f
        val sc = minOf((width - 2 * pad) / w, (height - 2 * pad) / h)
        val ox = (width - (w * sc).toFloat()) / 2f
        val oy = (height - (h * sc).toFloat()) / 2f
        val single = all.size == 1
        fun px(p: Pair<Double, Double>): Float = if (single) width / 2f else ox + ((p.second - minLo) * cosL * sc).toFloat()
        fun py(p: Pair<Double, Double>): Float = if (single) height / 2f else oy + ((maxLa - p.first) * sc).toFloat()
        routes.forEachIndexed { ri, r ->
            val n = r.size
            if (n < 2) return@forEachIndexed
            val last = ri == routes.size - 1
            val f = frac * (n - 1)
            val full = f.toInt().coerceAtMost(n - 1)
            val path = Path()
            path.moveTo(px(r[0]), py(r[0]))
            for (i in 1..full) path.lineTo(px(r[i]), py(r[i]))
            var hx = px(r[full]); var hy = py(r[full])
            if (full < n - 1) {
                val t = f - full
                hx += (px(r[full + 1]) - hx) * t; hy += (py(r[full + 1]) - hy) * t
                path.lineTo(hx, hy)
            }
            cv.drawPath(path, if (last) line else dim)
            if (last && marks.isEmpty()) {
                fp.color = 0xFF3DDC84.toInt()
                cv.drawRect(px(r[0]) - 10f, py(r[0]) - 10f, px(r[0]) + 10f, py(r[0]) + 10f, fp)
                fp.color = 0xFFFFFFFF.toInt()
                cv.drawCircle(hx, hy, 11f, fp)
            }
        }
        marks.forEachIndexed { i, m ->
            if (marks.size > 1 && i > frac * (marks.size - 1) + 0.001f) return@forEachIndexed
            val x = px(m); val y = py(m)
            val on = i == hi
            val r = if (on) 24f else 18f
            fp.color = if (on) 0xFFFFFFFF.toInt() else 0xFFFFC400.toInt()
            cv.drawRect(x - r, y - r, x + r, y + r, fp)
            cv.drawText((i + 1).toString(), x, y + 8f, num)
        }
        cv.drawText("N ^", width - 70f, 34f, txt)
        val m100 = (111320.0 / sc * 100).toInt()
        cv.drawLine(24f, height - 28f, 124f, height - 28f, line)
        cv.drawText("$m100 m", 134f, height - 20f, txt)
    }
}

data class Mod(val sec: String, val name: String, val desc: String, val scr: Int, val stat: String)

class MainActivity : Activity() {
    private lateinit var content: FrameLayout
    private val navIv = mutableListOf<ImageView>()
    private val navTv = mutableListOf<TextView>()
    private var cur = 0
    private var target: EditText? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun tv(t: String, sp: Float, col: Int, bold: Boolean = false) = TextView(this).apply {
        textSize = sp * 0.9f; setTextColor(col)
        if (sp >= 24f) { typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD); letterSpacing = 0.06f; text = t.uppercase() }
        else { typeface = if (bold) Typeface.create(Typeface.MONOSPACE, Typeface.BOLD) else Typeface.MONOSPACE; text = t }
    }
    private fun box(col: Int, r: Int, st: Int = 0) = GradientDrawable().apply {
        setColor(col); cornerRadius = dp(minOf(r, 2)).toFloat(); if (st != 0) setStroke(dp(1), st)
    }
    private fun grad(r: Int) = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, GR).apply { cornerRadius = dp(minOf(r, 2)).toFloat() }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = true; setTextColor(BG); typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD); letterSpacing = 0.08f
        background = grad(2); setOnClickListener { f() }
        setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_DOWN) v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(80).start()
            else if (e.action == MotionEvent.ACTION_UP || e.action == MotionEvent.ACTION_CANCEL) v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            false
        }
    }
    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) }
    private fun plate() = Plate(0xFF1D2025.toInt(), 0xFF3A3F47.toInt(), dp(14).toFloat())
    private fun glass() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = plate(); setPadding(dp(16), dp(14), dp(16), dp(14))
    }
    private fun page() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(52), dp(20), dp(24)) }
    private fun View.rise(i: Int) {
        alpha = 0f; translationX = -dp(28).toFloat()
        animate().alpha(1f).translationX(0f).setStartDelay(i * 70L).setDuration(450).setInterpolator(DecelerateInterpolator()).start()
    }
    private fun dlg() = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG; window.navigationBarColor = BG
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        Notif.channels(this)
        val root = FrameLayout(this).apply { setBackgroundColor(BG) }
        root.addView(Grid(this), FrameLayout.LayoutParams(-1, -1))
        root.addView(Rain(this).apply { alpha = 0.5f }, FrameLayout.LayoutParams(-1, -1))
        content = FrameLayout(this)
        root.addView(content, FrameLayout.LayoutParams(-1, -1).apply { bottomMargin = dp(72) })
        root.addView(nav(), FrameLayout.LayoutParams(-1, dp(72), Gravity.BOTTOM))
        root.addView(Belt(this), FrameLayout.LayoutParams(-1, dp(10), Gravity.TOP))
        val scan = View(this).apply { setBackgroundColor(0x2EFFC400) }
        root.addView(scan, FrameLayout.LayoutParams(-1, dp(2)))
        ObjectAnimator.ofFloat(scan, "translationY", 0f, resources.displayMetrics.heightPixels.toFloat()).apply {
            duration = 5000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        }.start()
        setContentView(root)
        show(0)
    }

    override fun onResume() { super.onResume(); show(cur) }

    private val navInd = mutableListOf<View>()

    private fun nav(): View {
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = box(0xFF0F1114.toInt(), 0, 0xFF3A3F47.toInt()) }
        val names = arrayOf("HARI INI", "JURNAL", "", "GRAFIK", "MENU")
        val icons = intArrayOf(R.drawable.ic_cal, R.drawable.ic_book, R.drawable.ic_spark, R.drawable.ic_chart, R.drawable.ic_grid)
        for (i in 0..4) {
            if (i == 2) {
                val orb = FrameLayout(this).apply { background = grad(2); setOnClickListener { assistant() }; setOnLongClickListener { quick(); true } }
                orb.addView(ImageView(this).apply { setImageResource(R.drawable.ic_spark); setColorFilter(BG) }, FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER))
                ObjectAnimator.ofPropertyValuesHolder(orb, PropertyValuesHolder.ofFloat("scaleX", 1f, 1.1f), PropertyValuesHolder.ofFloat("scaleY", 1f, 1.1f)).apply {
                    duration = 900; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE
                }.start()
                bar.addView(orb, LinearLayout.LayoutParams(dp(52), dp(52)).apply { marginStart = dp(14); marginEnd = dp(14) })
                navIv.add(ImageView(this)); navTv.add(TextView(this)); navInd.add(View(this))
                continue
            }
            val item = FrameLayout(this).apply { setOnClickListener { show(if (i > 2) i - 1 else i) } }
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
            val iv = ImageView(this).apply { setImageResource(icons[i]) }
            val t = tv(names[i], 10f, MU, true).apply { gravity = Gravity.CENTER }
            col.addView(iv, LinearLayout.LayoutParams(dp(24), dp(24)))
            col.addView(t, lp(2))
            val ind = View(this).apply { setBackgroundColor(YEL); visibility = View.INVISIBLE }
            item.addView(col, FrameLayout.LayoutParams(-1, -1))
            item.addView(ind, FrameLayout.LayoutParams(-1, dp(3), Gravity.TOP).apply { marginStart = dp(14); marginEnd = dp(14) })
            bar.addView(item, LinearLayout.LayoutParams(0, -1, 1f))
            navIv.add(iv); navTv.add(t); navInd.add(ind)
        }
        return bar
    }

    private fun show(n: Int) {
        cur = n
        tick?.let { h.removeCallbacks(it) }
        content.removeAllViews()
        val pg = when (n) { 0 -> today(); 1 -> journal(); 2 -> chart(); 3 -> menu(); 4 -> timer(); 5 -> consist(); 6 -> olahraga(); 7 -> perjalanan(); 8 -> kenangan(); 9 -> kontrol(); 10 -> pengulangan(); 11 -> status(); 12 -> petaOlahraga(); 13 -> linimasa(); else -> kelompok() }
        content.addView(ScrollView(this).apply { addView(pg); isVerticalScrollBarEnabled = false })
        for (i in 0..4) {
            if (i == 2) continue
            val on = i == (if (n == 2) 3 else if (n >= 3) 4 else n)
            navIv[i].setColorFilter(if (on) YEL else MU)
            navTv[i].setTextColor(if (on) YEL else MU)
            navInd[i].visibility = if (on) View.VISIBLE else View.INVISIBLE
            if (on) navInd[i].startAnimation(ScaleAnimation(0f, 1f, 1f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f).apply { duration = 350 })
        }
    }

    private fun today(): LinearLayout {
        val p = page()
        p.addView(tv(SimpleDateFormat("EEEE, d MMMM", Locale("id", "ID")).format(Date()), 13f, MU))
        p.addView(tv("Hari Ini", 30f, FG, true))
        p.addView(statusRow(), lp(6)); p.addView(term(), lp(10))
        val dow = Calendar.getInstance().get(Calendar.DAY_OF_WEEK) - 1
        val all = Store.all(this).filter { if (it.date > 0) Hist.day(it.date) == Hist.day() else (it.days == 0 || ((it.days shr dow) and 1) == 1) }
            .sortedWith(compareBy<Item>({ it.hour }, { it.minute }))
        val dn = all.count { Hist.isDone(this, it.id) }
        val hero = glass().apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val ring = Ring(this)
        hero.addView(ring, LinearLayout.LayoutParams(dp(96), dp(96)))
        val tx = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), 0, 0, 0) }
        tx.addView(tv("Progres hari ini", 13f, MU))
        tx.addView(tv("$dn dari ${all.size} selesai", 20f, FG, true))
        tx.addView(tv("Streak ${Hist.streak(this)} hari", 13f, CY, true))
        hero.addView(tx)
        p.addView(hero, lp(16)); hero.rise(0)
        ring.go(if (all.isEmpty()) 0f else dn.toFloat() / all.size)
        val nowSec = Calendar.getInstance().let { it.get(Calendar.HOUR_OF_DAY) * 3600 + it.get(Calendar.MINUTE) * 60 + it.get(Calendar.SECOND) }
        val pend = all.filter { !Hist.isDone(this, it.id) }
        val nx = pend.firstOrNull { it.hour * 3600 + it.minute * 60 >= nowSec } ?: pend.firstOrNull()
        if (nx != null) {
            val nc = glass().apply { background = Plate(0xFF241F0A.toInt(), YEL, dp(14).toFloat()) }
            nc.addView(tv(">> BERIKUTNYA", 11f, YEL, true))
            nc.addView(tv(nx.title.uppercase(), 18f, FG, true), lp(4))
            val cd = tv("", 22f, YEL, true)
            nc.addView(cd, lp(4))
            val nr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            nr.addView(btn("Mulai timer") { TimerStore.start(this, 25, nx.id); show(4) }, LinearLayout.LayoutParams(0, -2, 1f))
            nr.addView(btn("Selesai") { Hist.toggle(this, nx); show(cur) }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(10) })
            nc.addView(nr, lp(10))
            p.addView(nc, lp(12)); nc.rise(0)
            val upd = object : Runnable {
                override fun run() {
                    val c0 = Calendar.getInstance()
                    val now = c0.get(Calendar.HOUR_OF_DAY) * 3600 + c0.get(Calendar.MINUTE) * 60 + c0.get(Calendar.SECOND)
                    val diff = nx.hour * 3600 + nx.minute * 60 - now
                    cd.text = if (diff >= 0) "T-%02d:%02d:%02d".format(diff / 3600, diff % 3600 / 60, diff % 60) else "TERLEWAT %d MNT".format(-diff / 60)
                    h.postDelayed(this, 1000)
                }
            }
            tick = upd
            upd.run()
        }
        val br = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        br.addView(btn("+ Kegiatan") { addItem() }, LinearLayout.LayoutParams(0, -2, 1f))
        br.addView(btn("Asisten") { assistant() }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(10) })
        br.addView(btn("Timer") { show(4) }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(10) })
        p.addView(br, lp(12))
        if (all.isEmpty()) p.addView(tv("Belum ada kegiatan. Tambahkan lewat tombol di atas.", 14f, MU), lp(20))
        all.forEachIndexed { i, x -> val v = itemRow(x); v.rise(i + 1); p.addView(v, lp(10)) }
        return p
    }

    private fun itemRow(x: Item): View {
        val done = Hist.isDone(this, x.id)
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = plate(); setPadding(dp(14), dp(12), dp(14), dp(12)) }
        r.addView(tv("%02d.%02d".format(x.hour, x.minute), 15f, FG, true).apply { minWidth = dp(58) })
        r.addView(View(this).apply { background = box(Groups.color(this@MainActivity, x.grp), 6) }, LinearLayout.LayoutParams(dp(10), dp(10)).apply { marginEnd = dp(10) })
        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val ti = tv(x.title, 16f, if (x.on) FG else MU, true)
        if (done) ti.paintFlags = ti.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
        mid.addView(ti)
        mid.addView(tv(x.grp + " - " + (if (x.alarm) "alarm" else "pengingat") + " - " + rep(x.days) + " - foto " + Mems.all(this).count { it.link == x.title } + (if (x.on) "" else " - nonaktif"), 11f, MU))
        r.addView(mid, LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(tv(if (done) "Selesai" else "Tandai", 12f, if (done) CY else MU, true).apply {
            setPadding(dp(10), dp(10), dp(4), dp(10)); setOnClickListener { Hist.toggle(this@MainActivity, x); show(cur) }
        })
        r.addView(tv("Foto", 12f, YEL, true).apply { setPadding(dp(8), dp(10), dp(4), dp(10)); setOnClickListener { pickPhoto(x.title) } })
        r.setOnLongClickListener {
            dlg().setItems(arrayOf(if (x.on) "Nonaktifkan" else "Aktifkan", "Hapus")) { _, w ->
                if (w == 0) { upd(x.copy(on = !x.on)); show(cur) } else del(x)
            }.show()
            true
        }
        return r
    }

    private fun journal(): LinearLayout {
        val p = page()
        p.addView(tv("Jurnal", 30f, FG, true))
        val d = Hist.day()
        val dn = Hist.all(this).count { it.d == d }
        val js = Jrn.all(this)
        val nowD = js.count { Hist.day(it.t) == d }
        val rec = glass(); rec.rise(0)
        rec.addView(tv("Rekap hari ini", 13f, MU))
        rec.addView(tv("$dn kegiatan selesai dari ${Store.all(this).size}, $nowD catatan jurnal", 15f, FG, true), lp(4))
        p.addView(rec, lp(14))
        p.addView(btn("+ Tulis jurnal") { writeJ() }, lp(12))
        if (js.isEmpty()) p.addView(tv("Belum ada catatan. Ketuk tombol di atas, lalu tulis atau bicara.", 14f, MU), lp(20))
        js.forEachIndexed { i, j ->
            val c = glass(); c.rise(i + 1)
            c.addView(tv(SimpleDateFormat("d MMM, HH.mm", Locale("id", "ID")).format(Date(j.t)) + "  -  " + j.mood, 12f, CY, true))
            c.addView(tv(j.text, 15f, FG), lp(6))
            c.setOnLongClickListener {
                dlg().setMessage("Hapus catatan ini?").setPositiveButton("Hapus") { _, _ ->
                    Jrn.save(this, Jrn.all(this).filter { it.id != j.id }); show(cur)
                }.setNegativeButton("Batal", null).show()
                true
            }
            p.addView(c, lp(10))
        }
        return p
    }

    private fun chart(): LinearLayout {
        val p = page()
        p.addView(tv("Grafik", 30f, FG, true))
        val recs = Hist.all(this)
        val loc = Locale("id", "ID")
        val cal = Calendar.getInstance(); cal.add(Calendar.DAY_OF_YEAR, -6)
        val days = (0..6).map { val t = cal.timeInMillis; cal.add(Calendar.DAY_OF_YEAR, 1); t }
        val cnt = days.map { t -> recs.count { it.d == Hist.day(t) } }
        val mx = (cnt.maxOrNull() ?: 0).coerceAtLeast(1)
        val c1 = glass(); c1.rise(0)
        c1.addView(tv("Kegiatan selesai, 7 hari terakhir", 14f, FG, true))
        val bars = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM }
        days.forEachIndexed { i, t ->
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
            col.addView(tv(cnt[i].toString(), 11f, MU), LinearLayout.LayoutParams(-2, -2))
            val b = View(this).apply { background = box(if (i == 6) 0xFFFFC400.toInt() else 0x66FFC400, 8) }
            col.addView(b, LinearLayout.LayoutParams(dp(26), dp(6) + dp(90) * cnt[i] / mx).apply { topMargin = dp(4); bottomMargin = dp(4) })
            b.startAnimation(ScaleAnimation(1f, 1f, 0f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 1f).apply { duration = 700; startOffset = i * 80L; interpolator = DecelerateInterpolator() })
            col.addView(tv(SimpleDateFormat("EEE", loc).format(Date(t)), 11f, MU), LinearLayout.LayoutParams(-2, -2))
            bars.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        }
        c1.addView(bars, LinearLayout.LayoutParams(-1, dp(150)).apply { topMargin = dp(12) })
        val week = days.map { Hist.day(it) }.toSet()
        val byG = recs.filter { it.d in week }.groupingBy { it.g }.eachCount().entries.sortedByDescending { it.value }
        val c2 = glass(); c2.rise(1)
        c2.addView(tv("Per kelompok, 7 hari terakhir", 14f, FG, true))
        if (byG.isEmpty()) c2.addView(tv("Belum ada data. Tandai kegiatan selesai di Hari Ini.", 13f, MU), lp(8))
        val tot = byG.sumOf { it.value }.coerceAtLeast(1)
        byG.forEachIndexed { i, e ->
            c2.addView(tv(e.key + "  -  " + e.value, 13f, FG, true), lp(12))
            val tr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; weightSum = 100f; background = box(0x1AFFFFFF, 4) }
            val bar = View(this).apply { background = box(Groups.color(this@MainActivity, e.key), 4) }
            tr.addView(bar, LinearLayout.LayoutParams(0, dp(8), (100f * e.value / tot).coerceAtLeast(2f)))
            bar.startAnimation(ScaleAnimation(0f, 1f, 1f, 1f, Animation.RELATIVE_TO_SELF, 0f, Animation.RELATIVE_TO_SELF, 0.5f).apply { duration = 800; startOffset = i * 100L })
            c2.addView(tr, lp(6).apply { height = dp(8) })
        }
        fun tile(v: String, l: String): View { val g = glass(); g.addView(tv(v, 24f, CY, true)); g.addView(tv(l, 12f, MU)); g.rise(2); return g }
        val tl = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tl.addView(tile("${Hist.streak(this)} hari", "Streak"), LinearLayout.LayoutParams(0, -2, 1f))
        tl.addView(tile("${cnt.sum()}", "Selesai 7 hari"), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12) })
        p.addView(c1, lp(14)); p.addView(c2, lp(12)); p.addView(tl, lp(12))
        return p
    }

    private fun menu(): LinearLayout {
        val p = page()
        val hd = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        hd.addView(tv("Menu", 30f, FG, true), LinearLayout.LayoutParams(0, -2, 1f))
        val gear = ImageView(this).apply { setImageResource(R.drawable.ic_gear); setColorFilter(YEL) }
        hd.addView(gear, LinearLayout.LayoutParams(dp(28), dp(28)))
        keep(gear, ObjectAnimator.ofFloat(gear, "rotation", 0f, 360f).apply { duration = 8000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator() })
        p.addView(hd)
        p.addView(statusRow(), lp(6))
        val items = Store.all(this)
        val d = Hist.day()
        val dow = Calendar.getInstance().get(Calendar.DAY_OF_WEEK) - 1
        val todayItems = items.filter { if (it.date > 0) Hist.day(it.date) == d else (it.days == 0 || ((it.days shr dow) and 1) == 1) }
        val doneN = todayItems.count { Hist.isDone(this, it.id) }
        val dset = Hist.all(this).map { it.d }.toSet()
        val cal0 = Calendar.getInstance()
        var c14 = 0
        for (k in 0..13) { if (Hist.day(cal0.timeInMillis) in dset) c14++; cal0.add(Calendar.DAY_OF_YEAR, -1) }
        val ws = Wos.all(this)
        val km7 = ws.filter { it.t >= System.currentTimeMillis() - 7 * 86400000L }.sumOf { it.m.toDouble() } / 1000
        val pl = Places.all(this).filter { Hist.day(it.t) == d }
        val stay = pl.sumOf { it.dur }
        val tEnd = TimerStore.end(this)
        val tStat = if (tEnd > System.currentTimeMillis()) { val sc = (tEnd - System.currentTimeMillis()) / 1000; "%02d:%02d".format(sc / 60, sc % 60) } else TimerStore.minutesToday(this).toString() + " mnt"
        val mods = listOf(
            Mod("RENCANA", "Pengulangan", "Atur hari mingguan tiap kegiatan", 10, items.count { it.days != 0 }.toString() + " aktif"),
            Mod("RENCANA", "Status Harian", "Sudah dan belum dikerjakan", 11, doneN.toString() + "/" + todayItems.size),
            Mod("RENCANA", "Timer Fokus", "Sesi fokus dengan alarm", 4, tStat),
            Mod("RENCANA", "Konsistensi", "Skor dan jarak antar-penyelesaian", 5, (c14 * 100 / 14).toString() + "%"),
            Mod("AKTIVITAS", "Olahraga", "Jarak, kecepatan, dan pace", 6, "%.1f km".format(km7)),
            Mod("AKTIVITAS", "Peta Rute", "Rute olahraga di peta", 12, ws.count { routePts(it.route).size >= 2 }.toString() + " rute"),
            Mod("AKTIVITAS", "Perjalanan", "Tandai dan lacak tempat", 7, pl.size.toString() + " titik"),
            Mod("AKTIVITAS", "Linimasa", "Peta dan lama berhenti", 13, if (stay > 0) fmtDur(stay) else "-"),
            Mod("CATATAN", "Foto", "Kenangan per jadwal dan rekap", 8, Mems.all(this).size.toString() + " foto"),
            Mod("KONTROL", "Kontrol Ponsel", "Waktu layar dan media sosial", 9, if (hasUsage()) "AKTIF" else "IZIN"),
            Mod("KONTROL", "Kelompok", "Kelola kategori kegiatan", 14, Groups.all(this).size.toString())
        )
        val ov = glass(); ov.rise(0)
        ov.addView(tv("PUSAT MODUL // " + mods.size + " MODUL", 12f, YEL, true))
        ov.addView(tv("Ketik untuk mencari. Tahan tombol tengah di bawah untuk aksi cepat.", 11f, MU), lp(4))
        p.addView(ov, lp(10))
        val et = EditText(this).apply {
            hint = "> CARI MODUL..."; setHintTextColor(MU); setTextColor(FG); typeface = Typeface.MONOSPACE; textSize = 14f
            setSingleLine(true); background = Plate(PANEL, LINE, dp(8).toFloat()); setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        p.addView(et, lp(12))
        val lst = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        p.addView(lst, lp(4))
        fun fill(q: String) {
            lst.removeAllViews()
            var lastSec = ""
            var k = 0
            mods.forEachIndexed { i, m ->
                if (q.isNotBlank() && !(m.name + " " + m.desc + " " + m.sec).contains(q.trim(), true)) return@forEachIndexed
                if (m.sec != lastSec) { lastSec = m.sec; lst.addView(tv("// " + m.sec, 11f, MU, true), lp(if (k == 0) 8 else 16)) }
                val r = modRow(i + 1, m); r.rise(k++); lst.addView(r, lp(8))
            }
            if (k == 0) lst.addView(tv("-- tidak ada modul yang cocok --", 12f, MU), lp(16))
        }
        fill("")
        et.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(e: Editable?) { fill(e?.toString() ?: "") }
            override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d2: Int) {}
            override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d2: Int) {}
        })
        p.addView(btn("Izin alarm dan baterai") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }, lp(18))
        return p
    }

    private fun modRow(n: Int, m: Mod): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = Plate(PANEL, LINE, dp(12).toFloat()); setPadding(dp(12), dp(12), dp(14), dp(12))
        }
        r.addView(tv("%02d".format(n), 15f, BG, true).apply { gravity = Gravity.CENTER; background = box(YEL, 0) }, LinearLayout.LayoutParams(dp(42), dp(42)))
        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(8), 0) }
        mid.addView(tv(m.name.uppercase(), 15f, FG, true))
        mid.addView(tv(m.desc, 11f, MU), lp(2))
        r.addView(mid, LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(tv(m.stat, 13f, YEL, true))
        r.addView(tv(">", 16f, MU, true).apply { setPadding(dp(10), 0, 0, 0) })
        r.setOnClickListener { show(m.scr) }
        r.setOnTouchListener { v, e ->
            when (e.action) {
                android.view.MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.97f).scaleY(0.97f).setDuration(80).start()
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }
            false
        }
        return r
    }

    private fun kelompok(): LinearLayout {
        val p = page()
        p.addView(tv("Kelompok", 30f, FG, true))
        val items = Store.all(this)
        val c = glass(); c.rise(0)
        c.addView(tv("Kelompok kegiatan", 14f, FG, true))
        Groups.all(this).forEach { g ->
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(10), 0, dp(10)) }
            r.addView(View(this).apply { background = box(Groups.color(this@MainActivity, g), 6) }, LinearLayout.LayoutParams(dp(10), dp(10)).apply { marginEnd = dp(10) })
            r.addView(tv(g, 15f, FG), LinearLayout.LayoutParams(0, -2, 1f))
            r.addView(tv("${items.count { it.grp == g }} kegiatan", 12f, MU))
            r.setOnLongClickListener {
                if (g != "Umum") dlg().setMessage("Hapus kelompok $g?").setPositiveButton("Hapus") { _, _ ->
                    Groups.save(this, Groups.all(this) - g); show(cur)
                }.setNegativeButton("Batal", null).show()
                true
            }
            c.addView(r)
        }
        c.addView(tv("Tahan lama untuk menghapus kelompok.", 12f, MU), lp(4))
        c.addView(btn("+ Tambah kelompok") { addGroup() }, lp(10))
        p.addView(c, lp(14))
        return p
    }

    private fun quick() {
        dlg().setTitle("Aksi cepat").setItems(arrayOf("+ Kegiatan baru", "Asisten jadwal", "Timer fokus 25 menit", "Tandai lokasi sekarang", "Tambah foto", "Buka Olahraga")) { _, w ->
            when (w) {
                0 -> addItem()
                1 -> assistant()
                2 -> { TimerStore.start(this, 25, 0L); show(4) }
                3 -> mark()
                4 -> fotoSumber(null)
                else -> show(6)
            }
        }.show()
    }

    private val h = android.os.Handler(android.os.Looper.getMainLooper())
    private var tick: Runnable? = null

    override fun onPause() { super.onPause(); tick?.let { h.removeCallbacks(it) } }

    private fun timer(): LinearLayout {
        val p = page()
        p.addView(tv("Timer", 30f, FG, true))
        val big = tv("00:00", 52f, FG, true).apply { gravity = Gravity.CENTER }
        val info = tv("", 13f, MU).apply { gravity = Gravity.CENTER }
        val card = glass(); card.rise(0)
        card.addView(big, lp(8)); card.addView(info, lp(4))
        p.addView(card, lp(14))
        val items = Store.all(this)
        val names = arrayOf("Tanpa kegiatan") + items.map { it.title }
        val sp = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, names)
            background = box(0xFF1D2025.toInt(), 2, 0xFF3A3F47.toInt())
        }
        val et = EditText(this).apply {
            setText("25"); inputType = InputType.TYPE_CLASS_NUMBER; setTextColor(FG); gravity = Gravity.CENTER; textSize = 20f
        }
        val pr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(25, 45, 60).forEachIndexed { i, m ->
            pr.addView(btn("$m mnt") { et.setText(m.toString()) }, LinearLayout.LayoutParams(0, -2, 1f).apply { if (i > 0) marginStart = dp(8) })
        }
        p.addView(tv("Durasi (menit)", 13f, MU), lp(16))
        p.addView(et, lp(0)); p.addView(pr, lp(4))
        p.addView(tv("Kaitkan ke kegiatan (otomatis ditandai selesai)", 13f, MU), lp(14))
        p.addView(sp, lp(6))
        p.addView(btn("Mulai timer") {
            val m = et.text.toString().toIntOrNull() ?: 0
            if (m in 1..600) {
                TimerStore.start(this, m, if (sp.selectedItemPosition > 0) items[sp.selectedItemPosition - 1].id else 0L)
                show(cur)
            }
        }, lp(16))
        p.addView(btn("Batalkan timer") { TimerStore.cancel(this); show(cur) }, lp(8))
        val upd = object : Runnable {
            override fun run() {
                val left = TimerStore.end(this@MainActivity) - System.currentTimeMillis()
                if (TimerStore.end(this@MainActivity) > 0L && left > 0L) {
                    val s = left / 1000
                    big.text = "%02d:%02d".format(s / 60, s % 60)
                    info.text = "Sedang berjalan. Alarm berbunyi saat selesai."
                    h.postDelayed(this, 500)
                } else {
                    big.text = "00:00"
                    info.text = "Hari ini: ${TimerStore.minutesToday(this@MainActivity)} menit fokus"
                }
            }
        }
        tick = upd
        upd.run()
        return p
    }

    private fun consist(): LinearLayout {
        val p = page()
        p.addView(tv("Konsistensi", 30f, FG, true))
        val recs = Hist.all(this)
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        fun ep(d: String): Int = Math.round((fmt.parse(d)?.time ?: 0L) / 86400000.0).toInt()
        val today = ep(Hist.day())
        val dset = recs.map { ep(it.d) }.toSet()
        val s14 = (0..13).count { (today - it) in dset }
        val c1 = glass(); c1.rise(0)
        c1.addView(tv("Skor 14 hari terakhir", 13f, MU))
        c1.addView(tv("${s14 * 100 / 14}%  ($s14 dari 14 hari ada kegiatan selesai)", 17f, FG, true), lp(4))
        for (r in 0..3) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (ci in 0..6) {
                val back = 27 - (r * 7 + ci)
                val on = (today - back) in dset
                val cell = View(this).apply { background = box(if (on) 0xFFFFC400.toInt() else 0x1FFFFFFF, 6) }
                row.addView(cell, LinearLayout.LayoutParams(0, dp(30), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
                cell.alpha = 0f
                cell.animate().alpha(1f).setStartDelay((r * 7 + ci) * 25L).setDuration(300).start()
            }
            c1.addView(row, lp(if (r == 0) 12 else 0))
        }
        c1.addView(tv("Kotak terang = ada kegiatan selesai pada hari itu (28 hari)", 11f, MU), lp(8))
        p.addView(c1, lp(14))
        val items = Store.all(this)
        if (items.isEmpty()) p.addView(tv("Belum ada kegiatan.", 14f, MU), lp(16))
        var k = 1
        items.forEach { x ->
            val ds = recs.filter { it.id == x.id }.map { ep(it.d) }.distinct().sorted()
            val c = glass(); c.rise(k++)
            c.addView(tv(x.title, 15f, FG, true))
            val msg: String
            val col: Int
            if (ds.size < 2) {
                msg = "Butuh data: tandai selesai beberapa kali"; col = MU
            } else {
                val gaps = ds.zipWithNext { a, b -> b - a }.sorted()
                val typ = gaps[gaps.size / 2].coerceAtLeast(1)
                val since = today - ds.last()
                if (since <= typ) { msg = "Biasanya tiap $typ hari, terakhir $since hari lalu. Sesuai."; col = 0xFF34D399.toInt() }
                else { msg = "Biasanya tiap $typ hari, sudah $since hari. Terlambat ${since - typ} hari."; col = 0xFFFBBF24.toInt() }
            }
            c.addView(tv(msg, 13f, col, true), lp(4))
            p.addView(c, lp(10))
        }
        return p
    }

    private var running = false
    private var woStart = 0L
    private var woM = 0f
    private var lastL: Location? = null
    private var woType = "Lari"
    private var pendingHere: ((Location) -> Unit)? = null
    private val woPts = StringBuilder()
    private val ll = LL { l ->
        if (l.accuracy < 35f) {
            val pl = lastL
            if (pl == null || pl.distanceTo(l) >= 4f) {
                if (pl != null) woM += pl.distanceTo(l)
                woPts.append("%.5f,%.5f;".format(Locale.US, l.latitude, l.longitude))
                lastL = l
            }
        }
    }
    private val soc = setOf("com.whatsapp", "com.whatsapp.w4b", "com.instagram.android", "com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.facebook.katana", "com.facebook.lite", "com.twitter.android", "com.facebook.orca", "org.telegram.messenger", "com.snapchat.android", "com.instagram.barcelona", "com.google.android.youtube")

    override fun onDestroy() {
        super.onDestroy()
        if (running) try { getSystemService(LocationManager::class.java).removeUpdates(ll) } catch (e: Exception) {}
    }

    override fun onRequestPermissionsResult(rc: Int, ps: Array<out String>, gr: IntArray) {
        super.onRequestPermissionsResult(rc, ps, gr)
        if (gr.any { it == PackageManager.PERMISSION_GRANTED }) {
            if (rc == 2) startWo()
            if (rc == 4) toggleTrack()
            if (rc == 3) { pendingHere?.let { here(it) }; pendingHere = null }
        }
    }

    private fun pace(x: Float): String = "%d'%02d\"".format((x / 60).toInt(), (x % 60).toInt())
    private fun fmtMs(ms: Long): String { val m = ms / 60000; return if (m >= 60) "${m / 60} j ${m % 60} m" else "$m m" }

    private fun startWo() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 2); return
        }
        val lm = getSystemService(LocationManager::class.java)
        if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) { Toast.makeText(this, "Nyalakan GPS dulu", Toast.LENGTH_LONG).show(); return }
        woM = 0f; lastL = null; woPts.setLength(0); woStart = System.currentTimeMillis(); running = true
        lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1500L, 3f, ll)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        show(cur)
    }

    private fun stopWo() {
        getSystemService(LocationManager::class.java).removeUpdates(ll)
        window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val s = ((System.currentTimeMillis() - woStart) / 1000).toInt()
        running = false
        if (s >= 10) Wos.add(this, Wo(woStart, woType, s, woM, thinRoute(woPts.toString())))
        show(cur)
    }

    private fun olahraga(): LinearLayout {
        val p = page()
        p.addView(tv("Olahraga", 30f, FG, true))
        val card = glass(); card.rise(0)
        val big = tv("00:00:00", 40f, FG, true).apply { gravity = Gravity.CENTER }
        val sub = tv("0.00 km   0.0 km/jam   pace --", 13f, MU).apply { gravity = Gravity.CENTER }
        card.addView(big, lp(6)); card.addView(sub, lp(6))
        p.addView(card, lp(14))
        val sp = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("Lari", "Jalan", "Sepeda"))
            background = box(0xFF1D2025.toInt(), 2, 0xFF3A3F47.toInt())
        }
        if (!running) p.addView(sp, lp(12))
        p.addView(btn(if (running) "Berhenti dan simpan" else "Mulai") {
            if (running) stopWo() else { woType = sp.selectedItem.toString(); startWo() }
        }, lp(10))
        p.addView(tv("Biarkan aplikasi tetap terbuka selama berolahraga. Layar dijaga menyala.", 12f, MU), lp(6))
        p.addView(btn("Peta rute") { show(12) }, lp(10))
        val ws = Wos.all(this)
        val w7 = ws.filter { it.t >= System.currentTimeMillis() - 7 * 86400000L }
        val c2 = glass(); c2.rise(1)
        c2.addView(tv("7 hari terakhir", 14f, FG, true))
        c2.addView(tv("${w7.size} sesi, %.2f km, ${w7.sumOf { it.secs } / 60} menit".format(w7.sumOf { it.m.toDouble() } / 1000), 14f, FG), lp(6))
        val far = ws.maxByOrNull { it.m }
        val fast = ws.filter { it.m > 500f && it.secs > 0 }.maxByOrNull { it.m / it.secs }
        val rec = if (far == null) "Belum ada rekor." else "Terjauh: %.2f km (${far.type})".format(far.m / 1000) + (if (fast != null) "  -  Tercepat: %.1f km/jam".format(fast.m / fast.secs * 3.6f) else "")
        c2.addView(tv(rec, 13f, CY, true), lp(6))
        p.addView(c2, lp(12))
        ws.take(5).forEachIndexed { i, w ->
            val c = glass(); c.rise(i + 2)
            c.addView(tv(SimpleDateFormat("d MMM, HH.mm", Locale("id", "ID")).format(Date(w.t)) + "  -  " + w.type, 12f, CY, true))
            val km = w.m / 1000f
            c.addView(tv("%.2f km   %02d:%02d   pace %s".format(km, w.secs / 60, w.secs % 60, if (km > 0.02f) pace(w.secs / km) else "--"), 15f, FG, true), lp(4))
            p.addView(c, lp(10))
        }
        val upd = object : Runnable {
            override fun run() {
                if (running) {
                    val s = ((System.currentTimeMillis() - woStart) / 1000).toInt()
                    big.text = "%02d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
                    val km = woM / 1000f
                    val v = if (s > 0) km / s * 3600f else 0f
                    sub.text = "%.2f km   %.1f km/jam   pace %s".format(km, v, if (km > 0.02f) pace(s / km) else "--")
                    h.postDelayed(this, 1000)
                }
            }
        }
        tick = upd
        upd.run()
        return p
    }

    private fun here(cb: (Location) -> Unit) {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            pendingHere = cb
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 3)
            return
        }
        val lm = getSystemService(LocationManager::class.java)
        val best = listOf("gps", "network", "passive").mapNotNull { try { lm.getLastKnownLocation(it) } catch (e: Exception) { null } }.maxByOrNull { it.time }
        if (best != null && System.currentTimeMillis() - best.time < 120000L) { cb(best); return }
        val prov = if (lm.isProviderEnabled("gps")) "gps" else if (lm.isProviderEnabled("network")) "network" else null
        if (prov == null) { Toast.makeText(this, "Nyalakan lokasi/GPS dulu", Toast.LENGTH_LONG).show(); return }
        Toast.makeText(this, "Mencari lokasi...", Toast.LENGTH_SHORT).show()
        lm.requestSingleUpdate(prov, LL { l -> cb(l) }, null)
    }

    private fun mark() {
        here { l ->
            Thread {
                var n = "%.4f, %.4f".format(l.latitude, l.longitude)
                try {
                    if (android.location.Geocoder.isPresent()) {
                        val a = android.location.Geocoder(this, Locale("id", "ID")).getFromLocation(l.latitude, l.longitude, 1)
                        if (!a.isNullOrEmpty()) n = a[0].getAddressLine(0) ?: n
                    }
                } catch (e: Exception) {}
                runOnUiThread { nameDialog(l, n) }
            }.start()
        }
    }

    private fun nameDialog(l: Location, n: String) {
        val et = EditText(this).apply { setText(n) }
        val f = form(); f.addView(et)
        dlg().setTitle("Nama tempat").setView(f)
            .setPositiveButton("Simpan") { _, _ ->
                Places.save(this, Places.all(this) + Pl(System.currentTimeMillis(), l.latitude, l.longitude, et.text.toString().trim().ifEmpty { n }))
                show(cur)
            }.setNegativeButton("Batal", null).show()
    }

    private fun perjalanan(): LinearLayout {
        val p = page()
        p.addView(tv("Perjalanan", 30f, FG, true))
        p.addView(tv("Ketuk tombol saat tiba di suatu tempat untuk mencatat singgahan Anda.", 13f, MU), lp(4))
        p.addView(btn("Tandai lokasi sekarang") { mark() }, lp(12))
        p.addView(btn("Linimasa peta") { show(13) }, lp(8))
        val tp = getSharedPreferences("trk", MODE_PRIVATE)
        val trOn = tp.getBoolean("on", false)
        val tc = glass(); tc.rise(0)
        tc.addView(tv("PENANDAAN OTOMATIS // " + (if (trOn) "AKTIF" else "MATI"), 12f, if (trOn) YEL else MU, true))
        val st0 = tp.getLong("st", 0L)
        tc.addView(tv(if (trOn && st0 > 0L) "Sedang berhenti sejak " + SimpleDateFormat("HH.mm", Locale.US).format(Date(st0)) + " (" + (maxOf(tp.getLong("last", st0), st0) - st0) / 60000 + " mnt)" else "Tempat yang disinggahi minimal 5 menit dicatat otomatis beserta lama berhentinya.", 12f, FG), lp(6))
        tc.addView(btn(if (trOn) "Hentikan pelacakan" else "Mulai pelacakan otomatis") { toggleTrack() }, lp(10))
        p.addView(tc, lp(10))
        val all = Places.all(this)
        if (all.isEmpty()) p.addView(tv("Belum ada tempat tercatat.", 14f, MU), lp(16))
        val fd = SimpleDateFormat("EEEE, d MMMM", Locale("id", "ID"))
        val ft = SimpleDateFormat("HH.mm", Locale.US)
        var idx = 1
        all.groupBy { Hist.day(it.t) }.entries.sortedByDescending { it.key }.take(7).forEach { e ->
            val sorted = e.value.sortedBy { it.t }
            var tot = 0f
            val c = glass(); c.rise(idx++)
            val head = tv("", 14f, FG, true)
            c.addView(head)
            sorted.forEachIndexed { i, pl ->
                var leg = ""
                if (i > 0) {
                    val r = FloatArray(1)
                    Location.distanceBetween(sorted[i - 1].lat, sorted[i - 1].lng, pl.lat, pl.lng, r)
                    tot += r[0]
                    leg = "  (+%.1f km)".format(r[0] / 1000)
                }
                val row = tv(ft.format(Date(pl.t)) + "  " + pl.name + leg + (if (pl.dur > 0) "  [" + fmtDur(pl.dur) + "]" else ""), 13f, FG)
                row.setOnLongClickListener {
                    dlg().setMessage("Hapus tempat ini?").setPositiveButton("Hapus") { _, _ ->
                        Places.save(this, Places.all(this).filter { it.t != pl.t }); show(cur)
                    }.setNegativeButton("Batal", null).show()
                    true
                }
                c.addView(row, lp(8))
            }
            head.text = fd.format(Date(sorted[0].t)) + "  -  ${sorted.size} tempat, %.1f km".format(tot / 1000)
            p.addView(c, lp(12))
        }
        return p
    }

    private fun thumb(path: String, w: Int = 800): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, o)
        var s = 1
        while (o.outWidth / (s * 2) >= w) s *= 2
        val bm = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s }) ?: return null
        return try {
            val rot = when (android.media.ExifInterface(path).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
            if (rot != 0f) Bitmap.createBitmap(bm, 0, 0, bm.width, bm.height, Matrix().apply { postRotate(rot) }, true) else bm
        } catch (e: Exception) { bm }
    }

    private var photoLink = ""
    private var camName = ""

    private fun pickPhoto(link: String) {
        photoLink = link
        dlg().setItems(arrayOf("Ambil foto dengan kamera", "Pilih dari galeri")) { _, w ->
            if (w == 0) {
                camName = "m" + System.currentTimeMillis() + ".jpg"
                try {
                    val u = androidx.core.content.FileProvider.getUriForFile(this, "app.jadwal.asisten.fp", File(filesDir, camName))
                    startActivityForResult(Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE).putExtra(android.provider.MediaStore.EXTRA_OUTPUT, u)
                        .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION), 89)
                } catch (e: Exception) { Toast.makeText(this, "Kamera tidak tersedia", Toast.LENGTH_LONG).show() }
            } else startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE), 88)
        }.show()
    }

    private fun photoDialog(u: Uri) {
        val name = "m" + System.currentTimeMillis() + ".jpg"
        try {
            contentResolver.openInputStream(u)?.use { i -> File(filesDir, name).outputStream().use { o -> i.copyTo(o) } }
        } catch (e: Exception) { Toast.makeText(this, "Foto gagal dibaca", Toast.LENGTH_LONG).show(); return }
        finishPhoto(name)
    }

    private fun finishPhoto(name: String) {
        val items = Store.all(this)
        val f = form()
        val et = EditText(this).apply { hint = "Keterangan foto" }
        val sp = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("Tanpa kegiatan") + items.map { it.title })
            setSelection(items.indexOfFirst { it.title == photoLink } + 1)
        }
        f.addView(et); f.addView(sp)
        dlg().setTitle("Foto baru").setView(f).setCancelable(false)
            .setPositiveButton("Simpan") { _, _ ->
                val now = System.currentTimeMillis()
                Mems.save(this, Mems.all(this) + Mm(now, now, name, et.text.toString().trim(), if (sp.selectedItemPosition > 0) items[sp.selectedItemPosition - 1].title else ""))
                show(cur)
            }.setNegativeButton("Batal") { _, _ -> File(filesDir, name).delete() }.show()
    }

    private fun showPhoto(m: Mm) {
        val f = form()
        f.addView(ImageView(this).apply { setImageBitmap(thumb(File(filesDir, m.file).path, 1000)); adjustViewBounds = true }, LinearLayout.LayoutParams(-1, -2))
        f.addView(tv(m.cap.ifEmpty { "Tanpa keterangan" }, 14f, FG, true), lp(8))
        f.addView(tv(SimpleDateFormat("d MMM yyyy, HH.mm", Locale("id", "ID")).format(Date(m.t)) + (if (m.link.isNotEmpty()) "  -  " + m.link else ""), 11f, MU), lp(2))
        dlg().setView(ScrollView(this).apply { addView(f) }).setPositiveButton("Tutup", null)
            .setNegativeButton("Hapus") { _, _ ->
                File(filesDir, m.file).delete(); Mems.save(this, Mems.all(this).filter { it.id != m.id }); show(cur)
            }.show()
    }

    private fun kenangan(): LinearLayout {
        val p = page()
        p.addView(tv("Foto", 30f, FG, true))
        p.addView(btn("+ Tambah foto") { pickPhoto("") }, lp(12))
        val ms = Mems.all(this)
        val d = Hist.day()
        val rec = glass(); rec.rise(0)
        rec.addView(tv("REKAP FOTO", 11f, MU, true))
        rec.addView(tv("${ms.size} foto total, ${ms.count { Hist.day(it.t) == d }} hari ini", 16f, FG, true), lp(4))
        val byK = ms.filter { it.link.isNotEmpty() }.groupingBy { it.link }.eachCount().entries.sortedByDescending { it.value }.take(6)
        val mx = byK.firstOrNull()?.value ?: 1
        byK.forEachIndexed { i, e ->
            rec.addView(tv(e.key + "  -  " + e.value, 12f, FG), lp(10))
            val tr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; weightSum = 100f; background = box(0x1AFFFFFF, 2) }
            val bar = View(this).apply { background = box(YEL, 2) }
            tr.addView(bar, LinearLayout.LayoutParams(0, dp(6), (100f * e.value / mx).coerceAtLeast(4f)))
            bar.startAnimation(ScaleAnimation(0f, 1f, 1f, 1f, Animation.RELATIVE_TO_SELF, 0f, Animation.RELATIVE_TO_SELF, 0.5f).apply { duration = 800; startOffset = i * 100L })
            rec.addView(tr, lp(4).apply { height = dp(6) })
        }
        p.addView(rec, lp(14))
        if (ms.isEmpty()) p.addView(tv("Belum ada foto. Ketuk Foto pada kegiatan di Hari Ini, atau tombol di atas.", 13f, MU), lp(16))
        var k = 1
        val fd = SimpleDateFormat("EEEE, d MMMM", Locale("id", "ID"))
        ms.groupBy { Hist.day(it.t) }.entries.sortedByDescending { it.key }.forEach { e ->
            val c = glass(); c.rise(k++)
            c.addView(tv(fd.format(Date(e.value[0].t)) + "  -  " + e.value.size + " foto", 13f, YEL, true))
            val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
            val strip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            e.value.forEach { m ->
                val cell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                val iv = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; background = box(0x1FFFFFFF, 2); setImageBitmap(thumb(File(filesDir, m.file).path, 240)) }
                iv.setOnClickListener { showPhoto(m) }
                cell.addView(iv, LinearLayout.LayoutParams(dp(96), dp(96)))
                cell.addView(tv(m.link.ifEmpty { "-" }, 10f, MU).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }, LinearLayout.LayoutParams(dp(96), -2))
                strip.addView(cell, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(8) })
            }
            hs.addView(strip)
            c.addView(hs, lp(10))
            p.addView(c, lp(12))
        }
        return p
    }

    private fun hasUsage(): Boolean {
        val a = getSystemService(AppOpsManager::class.java)
        val m = if (Build.VERSION.SDK_INT >= 29) a.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
        else @Suppress("DEPRECATION") a.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
        return m == AppOpsManager.MODE_ALLOWED
    }

    private fun label(pk: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pk, 0)).toString()
    } catch (e: Exception) { pk.substringAfterLast('.') }

    private fun setLim() {
        val et = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(getSharedPreferences("ctl", MODE_PRIVATE).getInt("lim", 60).toString()) }
        val f = form(); f.addView(et)
        dlg().setTitle("Batas media sosial (menit per hari)").setView(f)
            .setPositiveButton("Simpan") { _, _ ->
                val v = et.text.toString().toIntOrNull() ?: 0
                if (v in 5..1440) { getSharedPreferences("ctl", MODE_PRIVATE).edit().putInt("lim", v).apply(); show(cur) }
            }.setNegativeButton("Batal", null).show()
    }

    private fun kontrol(): LinearLayout {
        val p = page()
        p.addView(tv("Kontrol Ponsel", 30f, FG, true))
        if (!hasUsage()) {
            val c = glass(); c.rise(0)
            c.addView(tv("Aplikasi perlu izin akses data penggunaan untuk membaca waktu layar. Data tetap di HP Anda.", 14f, FG))
            c.addView(btn("Buka pengaturan izin") { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }, lp(10))
            p.addView(c, lp(14))
            return p
        }
        val um = getSystemService(UsageStatsManager::class.java)
        val c0 = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        val ls = um.queryAndAggregateUsageStats(c0.timeInMillis, System.currentTimeMillis()).values
            .filter { it.totalTimeInForeground > 60000L && it.packageName != packageName }.sortedByDescending { it.totalTimeInForeground }
        val total = ls.sumOf { it.totalTimeInForeground }
        val sosMs = ls.filter { it.packageName in soc }.sumOf { it.totalTimeInForeground }
        val lim = getSharedPreferences("ctl", MODE_PRIVATE).getInt("lim", 60)
        val c1 = glass(); c1.rise(0)
        c1.addView(tv("Waktu layar hari ini", 13f, MU))
        c1.addView(tv(fmtMs(total), 26f, FG, true), lp(2))
        p.addView(c1, lp(14))
        val c2 = glass(); c2.rise(1)
        c2.addView(tv("Media sosial hari ini", 13f, MU))
        c2.addView(tv(fmtMs(sosMs) + " dari batas " + lim + " menit", 17f, FG, true), lp(2))
        val pct = (sosMs * 100 / (lim * 60000L)).coerceAtMost(100L).toInt()
        val tr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; weightSum = 100f; background = box(0x1AFFFFFF, 4) }
        tr.addView(View(this).apply { background = box(if (pct >= 80) 0xFFFBBF24.toInt() else 0xFFFFC400.toInt(), 4) }, LinearLayout.LayoutParams(0, dp(8), pct.coerceAtLeast(1).toFloat()))
        c2.addView(tr, lp(10).apply { height = dp(8) })
        if (pct >= 100) c2.addView(tv("Batas terlampaui. Coba rehat dulu dari media sosial.", 13f, 0xFFFBBF24.toInt(), true), lp(8))
        c2.addView(btn("Atur batas harian") { setLim() }, lp(10))
        p.addView(c2, lp(12))
        val c3 = glass(); c3.rise(2)
        c3.addView(tv("Aplikasi paling sering dipakai", 14f, FG, true))
        ls.take(8).forEach { u ->
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, 0) }
            r.addView(tv(label(u.packageName), 14f, FG), LinearLayout.LayoutParams(0, -2, 1f))
            r.addView(tv(fmtMs(u.totalTimeInForeground), 13f, CY, true))
            c3.addView(r)
        }
        p.addView(c3, lp(12))
        return p
    }

    private val DN = arrayOf("SEN", "SEL", "RAB", "KAM", "JUM", "SAB", "MIN")
    private val DB = intArrayOf(1, 2, 3, 4, 5, 6, 0)

    private fun rep(m: Int): String =
        if (m == 0) "sekali" else if (m == 127) "harian" else (0..6).filter { ((m shr DB[it]) and 1) == 1 }.joinToString(" ") { DN[it].lowercase() }

    private fun dayRow(init: Int, cb: (Int) -> Unit): LinearLayout {
        var m = init
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val cells = mutableListOf<TextView>()
        fun paint() {
            for (k in 0..6) {
                val on = ((m shr DB[k]) and 1) == 1
                cells[k].background = box(if (on) YEL else 0x1FFFFFFF, 2)
                cells[k].setTextColor(if (on) BG else MU)
            }
        }
        for (k in 0..6) {
            val t = tv(DN[k], 10f, MU, true).apply { gravity = Gravity.CENTER }
            t.setOnClickListener { m = m xor (1 shl DB[k]); paint(); cb(m) }
            cells.add(t)
            row.addView(t, LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginEnd = dp(4) })
        }
        paint()
        return row
    }

    private fun pengulangan(): LinearLayout {
        val p = page()
        p.addView(tv("Pengulangan", 30f, FG, true))
        p.addView(tv("Ketuk hari untuk mengatur jadwal mingguan tiap kegiatan. Tanpa hari terpilih berarti sekali saja.", 12f, MU), lp(4))
        val all = Store.all(this).sortedWith(compareBy<Item>({ it.hour }, { it.minute }))
        val ov = glass(); ov.rise(0)
        ov.addView(tv("BEBAN PER HARI", 11f, MU, true))
        val rw = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (k in 0..6) {
            val n = all.count { it.on && ((it.days shr DB[k]) and 1) == 1 }
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
            col.addView(tv(n.toString(), 18f, if (n > 0) YEL else MU, true))
            col.addView(tv(DN[k], 10f, MU))
            rw.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        }
        ov.addView(rw, lp(8))
        p.addView(ov, lp(14))
        if (all.isEmpty()) p.addView(tv("Belum ada kegiatan.", 14f, MU), lp(16))
        all.forEachIndexed { i, x ->
            val c = glass(); c.rise(i + 1)
            c.addView(tv("%02d.%02d  %s".format(x.hour, x.minute, x.title), 15f, FG, true))
            c.addView(dayRow(x.days) { nd -> upd(x.copy(days = nd, on = if (nd != 0) true else x.on)) }, lp(10))
            p.addView(c, lp(10))
        }
        return p
    }

    private fun keep(v: View, a: ObjectAnimator) {
        v.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(x: View) {}
            override fun onViewDetachedFromWindow(x: View) { a.cancel() }
        })
        a.start()
    }

    private fun statusRow(): View {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val led = View(this).apply { background = box(0xFF3DDC84.toInt(), 2) }
        r.addView(led, LinearLayout.LayoutParams(dp(8), dp(8)).apply { marginEnd = dp(8) })
        keep(led, ObjectAnimator.ofFloat(led, "alpha", 1f, 0.2f).apply { duration = 700; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE })
        r.addView(tv("SISTEM AKTIF // " + SimpleDateFormat("dd.MM.yyyy", Locale.US).format(Date()), 11f, MU))
        return r
    }

    private fun termLines(): List<String> {
        val its = Store.all(this)
        val d = Hist.day()
        val dn = its.count { Hist.isDone(this, it.id, d) }
        val nx = its.filter { it.on }.mapNotNull { x -> val t = Sched.next(x); if (t > 0) Pair(t, x) else null }.minByOrNull { it.first }
        val nxs = if (nx != null) SimpleDateFormat("EEE HH.mm", Locale("id", "ID")).format(Date(nx.first)) + " " + nx.second.title else "--"
        return listOf(
            "> sys.boot --jadwal v4.0",
            "> load kegiatan ........ ${its.size} OK",
            "> selesai_hari_ini ..... $dn/${its.size}",
            "> streak ............... ${Hist.streak(this)} hari",
            "> alarm_next ........... $nxs",
            "fun jadwal() {",
            "  for (k in kegiatan) {",
            "    if (!k.selesai) ingatkan(k)",
            "    else catat(k.foto)",
            "  }",
            "}",
            "> status: SIAGA"
        )
    }

    private fun term(): View {
        val t = Term(this)
        t.background = box(0xFF0D0F12.toInt(), 2, 0xFF3A3F47.toInt())
        t.setPadding(dp(12), dp(10), dp(12), dp(10))
        t.start(termLines())
        t.rise(0)
        return t
    }

    private var statOff = 0
    private var statF = 0

    private fun status(): LinearLayout {
        val p = page()
        p.addView(tv("Status Harian", 30f, FG, true))
        val cal = Calendar.getInstance(); cal.add(Calendar.DAY_OF_YEAR, statOff)
        val ds = Hist.day(cal.timeInMillis)
        val isToday = statOff == 0
        val dow = cal.get(Calendar.DAY_OF_WEEK) - 1
        val nr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        nr.addView(btn("<") { statOff -= 1; show(cur) }, LinearLayout.LayoutParams(dp(56), -2))
        nr.addView(tv(SimpleDateFormat("EEEE, d MMM yyyy", Locale("id", "ID")).format(cal.time), 12f, YEL, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(0, -2, 1f))
        nr.addView(btn(">") { if (statOff < 0) { statOff += 1; show(cur) } }, LinearLayout.LayoutParams(dp(56), -2))
        p.addView(nr, lp(12))
        val items = Store.all(this).filter { x ->
            val sched = if (x.date > 0) Hist.day(x.date) == ds else (x.days != 0 && ((x.days shr dow) and 1) == 1) || (x.days == 0 && isToday)
            (sched && (isToday || x.cr == 0L || Hist.day(x.cr) <= ds)) || Hist.isDone(this, x.id, ds)
        }.sortedWith(compareBy<Item>({ it.hour }, { it.minute }))
        val done = items.filter { Hist.isDone(this, it.id, ds) }
        val todo = items.filter { !Hist.isDone(this, it.id, ds) }
        val pct = if (items.isEmpty()) 0 else done.size * 100 / items.size
        val sm = glass(); sm.rise(0)
        sm.addView(tv("SELESAI " + done.size + " DARI " + items.size + "  //  " + pct + "%", 14f, FG, true))
        val tr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; weightSum = 100f; background = box(0x1AFFFFFF, 2) }
        val bar = View(this).apply { background = box(YEL, 2) }
        tr.addView(bar, LinearLayout.LayoutParams(0, dp(8), pct.coerceAtLeast(1).toFloat()))
        bar.startAnimation(ScaleAnimation(0f, 1f, 1f, 1f, Animation.RELATIVE_TO_SELF, 0f, Animation.RELATIVE_TO_SELF, 0.5f).apply { duration = 900 })
        sm.addView(tr, lp(10).apply { height = dp(8) })
        p.addView(sm, lp(12))
        val fr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("SEMUA" to 0, "BELUM " + todo.size to 1, "SELESAI " + done.size to 2).forEachIndexed { i, q ->
            val on = statF == q.second
            val t = tv(q.first, 11f, if (on) BG else MU, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(12)); background = box(if (on) YEL else 0x1FFFFFFF, 2) }
            t.setOnClickListener { statF = q.second; show(cur) }
            fr.addView(t, LinearLayout.LayoutParams(0, -2, 1f).apply { if (i > 0) marginStart = dp(6) })
        }
        p.addView(fr, lp(10))
        val nowMin = Calendar.getInstance().let { it.get(Calendar.HOUR_OF_DAY) * 60 + it.get(Calendar.MINUTE) }
        var k = 1
        fun section(title: String, list: List<Item>, ok: Boolean) {
            val c = glass(); c.rise(k++)
            c.addView(tv(title + "  [" + list.size + "]", 13f, if (ok) YEL else FG, true))
            if (list.isEmpty()) c.addView(tv(if (ok) "-- belum ada yang selesai --" else "-- semua sudah dikerjakan --", 12f, MU), lp(8))
            list.forEach { x ->
                val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(10), 0, dp(2)) }
                r.addView(View(this).apply { background = box(Groups.color(this@MainActivity, x.grp), 2) }, LinearLayout.LayoutParams(dp(10), dp(10)).apply { marginEnd = dp(10) })
                r.addView(tv("%02d.%02d".format(x.hour, x.minute), 13f, FG, true).apply { minWidth = dp(54) })
                r.addView(tv(x.title, 14f, FG), LinearLayout.LayoutParams(0, -2, 1f))
                val late = !ok && (!isToday || x.hour * 60 + x.minute < nowMin)
                r.addView(tv(if (ok) "SELESAI" else if (late) "TERLEWAT" else "MENUNGGU", 10f, if (ok) YEL else if (late) 0xFFFB923C.toInt() else MU, true))
                if (isToday) r.setOnClickListener { Hist.toggle(this@MainActivity, x); show(cur) }
                c.addView(r)
            }
            p.addView(c, lp(10))
        }
        if (statF != 2) section("BELUM DIKERJAKAN", todo, false)
        if (statF != 1) section("SUDAH DIKERJAKAN", done, true)
        p.addView(tv(if (isToday) "Ketuk kegiatan untuk menandai selesai atau membatalkan." else "Hari lampau hanya untuk dilihat.", 11f, MU), lp(12))
        return p
    }

    private var mapSel = 0

    private fun petaOlahraga(): LinearLayout {
        val p = page()
        p.addView(tv("Peta Rute", 30f, FG, true))
        val ws = Wos.all(this).filter { routePts(it.route).size >= 2 }
        if (ws.isEmpty()) {
            val c = glass(); c.rise(0)
            c.addView(tv("Belum ada rute tersimpan. Mulai olahraga dengan GPS menyala, dan rute terekam otomatis. Sesi lama tanpa rute tidak bisa ditampilkan.", 13f, FG))
            c.addView(btn("Ke menu olahraga") { show(6) }, lp(10))
            p.addView(c, lp(14))
            return p
        }
        if (mapSel > ws.size) mapSel = 0
        val sel = if (mapSel == 0) ws.take(10).reversed() else listOf(ws[mapSel - 1])
        val frame = LinearLayout(this).apply { background = Plate(0xFF0D0F12.toInt(), 0xFF3A3F47.toInt(), dp(12).toFloat()); setPadding(dp(6), dp(6), dp(6), dp(6)) }
        val map = RouteMap(this)
        frame.addView(map, LinearLayout.LayoutParams(-1, dp(300)))
        p.addView(frame, lp(12)); frame.rise(0)
        map.set(sel.map { routePts(it.route) })
        val fd = SimpleDateFormat("EEE, d MMM yyyy, HH.mm", Locale("id", "ID"))
        val st = glass(); st.rise(1)
        if (mapSel == 0) {
            st.addView(tv(sel.size.toString() + " RUTE TERAKHIR DITUMPUK", 12f, YEL, true))
            st.addView(tv("Total %.2f km".format(sel.sumOf { it.m.toDouble() } / 1000), 15f, FG, true), lp(4))
        } else {
            val w = ws[mapSel - 1]
            val km = w.m / 1000f
            st.addView(tv(fd.format(Date(w.t)).uppercase() + "  //  " + w.type.uppercase(), 12f, YEL, true))
            st.addView(tv("%.2f km   %02d:%02d".format(km, w.secs / 60, w.secs % 60), 18f, FG, true), lp(4))
            st.addView(tv("pace %s   %.1f km/jam".format(if (km > 0.02f) pace(w.secs / km) else "--", if (w.secs > 0) km / w.secs * 3600f else 0f), 13f, MU), lp(4))
        }
        p.addView(st, lp(10))
        if (mapSel > 0) {
            val f0 = routePts(ws[mapSel - 1].route)[0]
            p.addView(btn("Buka titik awal di aplikasi peta") {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:" + f0.first + "," + f0.second + "?q=" + f0.first + "," + f0.second + "(" + Uri.encode("Titik awal") + ")")))
                } catch (e: Exception) { Toast.makeText(this, "Aplikasi peta tidak ditemukan", Toast.LENGTH_LONG).show() }
            }, lp(10))
        }
        p.addView(tv("PILIH RUTE", 11f, MU, true), lp(16))
        fun chip(label: String, idx: Int, d: Int) {
            val on = mapSel == idx
            val t = tv(label, 12f, if (on) BG else FG, true).apply {
                setPadding(dp(14), dp(14), dp(14), dp(14)); background = box(if (on) YEL else 0xFF1D2025.toInt(), 2, 0xFF3A3F47.toInt())
            }
            t.setOnClickListener { mapSel = idx; show(cur) }
            t.rise(d)
            p.addView(t, lp(8))
        }
        chip("SEMUA (10 TERAKHIR)", 0, 2)
        ws.forEachIndexed { i, w -> chip(fd.format(Date(w.t)) + "  -  " + w.type + "  -  " + "%.2f km".format(w.m / 1000), i + 1, i + 3) }
        return p
    }

    private var tlOff = 0
    private var tlSel = -1

    private fun linimasa(): LinearLayout {
        val p = page()
        p.addView(tv("Linimasa", 30f, FG, true))
        val cal = Calendar.getInstance(); cal.add(Calendar.DAY_OF_YEAR, tlOff)
        val ds = Hist.day(cal.timeInMillis)
        val nr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        nr.addView(btn("<") { tlOff -= 1; tlSel = -1; show(cur) }, LinearLayout.LayoutParams(dp(56), -2))
        nr.addView(tv(SimpleDateFormat("EEEE, d MMM yyyy", Locale("id", "ID")).format(cal.time), 12f, YEL, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(0, -2, 1f))
        nr.addView(btn(">") { if (tlOff < 0) { tlOff += 1; tlSel = -1; show(cur) } }, LinearLayout.LayoutParams(dp(56), -2))
        p.addView(nr, lp(12))
        val pts = Places.all(this).filter { Hist.day(it.t) == ds }.sortedBy { it.t }
        if (pts.isEmpty()) {
            val c = glass(); c.rise(0)
            c.addView(tv("Belum ada tempat tercatat pada hari ini. Ketuk Tandai lokasi sekarang di menu Perjalanan saat tiba di suatu tempat.", 13f, FG))
            c.addView(btn("Ke menu perjalanan") { show(7) }, lp(10))
            p.addView(c, lp(14))
            return p
        }
        if (tlSel >= pts.size) tlSel = -1
        val leg = FloatArray(pts.size)
        for (i in 1 until pts.size) {
            val r = FloatArray(1)
            Location.distanceBetween(pts[i - 1].lat, pts[i - 1].lng, pts[i].lat, pts[i].lng, r)
            leg[i] = r[0]
        }
        val frame = LinearLayout(this).apply { background = Plate(0xFF0D0F12.toInt(), 0xFF3A3F47.toInt(), dp(12).toFloat()); setPadding(dp(6), dp(6), dp(6), dp(6)) }
        val map = RouteMap(this)
        frame.addView(map, LinearLayout.LayoutParams(-1, dp(280)))
        p.addView(frame, lp(12)); frame.rise(0)
        val ll2 = pts.map { Pair(it.lat, it.lng) }
        map.set(listOf(ll2)); map.setMarks(ll2, tlSel)
        val ft = SimpleDateFormat("HH.mm", Locale.US)
        val span = ((pts.last().t - pts.first().t) / 60000).toInt()
        val sm = glass(); sm.rise(1)
        sm.addView(tv(pts.size.toString() + " TEMPAT  //  %.1f km".format(leg.sum() / 1000), 14f, YEL, true))
        sm.addView(tv(ft.format(Date(pts.first().t)) + " sampai " + ft.format(Date(pts.last().t)) + "  (" + span / 60 + " j " + span % 60 + " m)", 12f, MU), lp(4))
        val stay = pts.sumOf { it.dur }
        if (stay > 0) sm.addView(tv("Total berhenti: " + fmtDur(stay), 12f, YEL, true), lp(4))
        p.addView(sm, lp(10))
        pts.forEachIndexed { i, pl ->
            val on = i == tlSel
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(tv(ft.format(Date(pl.t)), 13f, if (on) YEL else FG, true).apply { minWidth = dp(56); setPadding(0, dp(2), 0, 0) })
            val rail = FrameLayout(this)
            rail.addView(View(this).apply { setBackgroundColor(0xFF3A3F47.toInt()) }, FrameLayout.LayoutParams(dp(2), -1, Gravity.CENTER_HORIZONTAL))
            rail.addView(View(this).apply { setBackgroundColor(if (on) 0xFFFFFFFF.toInt() else YEL) }, FrameLayout.LayoutParams(dp(14), dp(14), Gravity.CENTER_HORIZONTAL))
            row.addView(rail, LinearLayout.LayoutParams(dp(30), -1))
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(18)) }
            info.addView(tv((i + 1).toString() + ". " + pl.name, 14f, if (on) YEL else FG, true))
            if (i > 0) {
                val mn = ((pl.t - pts[i - 1].t) / 60000).toInt()
                val sp = if (mn > 0) leg[i] / 1000f / (mn / 60f) else 0f
                info.addView(tv("+%.1f km  -  %d mnt dari titik %d  -  ~%.1f km/jam".format(leg[i] / 1000, mn, i, sp), 11f, MU), lp(3))
            } else info.addView(tv("titik awal hari ini", 11f, MU), lp(3))
            if (pl.dur > 0) info.addView(tv("berhenti " + fmtDur(pl.dur) + " (otomatis)", 11f, YEL, true), lp(3))
            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            row.setOnClickListener { tlSel = if (tlSel == i) -1 else i; show(cur) }
            row.setOnLongClickListener { placeMenu(pl); true }
            row.rise(i + 2)
            p.addView(row, lp(if (i == 0) 14 else 0))
        }
        return p
    }

    private fun fmtDur(m: Int): String = if (m >= 60) (m / 60).toString() + " j " + (m % 60) + " m" else m.toString() + " m"

    private fun toggleTrack() {
        val tp = getSharedPreferences("trk", MODE_PRIVATE)
        if (tp.getBoolean("on", false)) {
            startService(Intent(this, TrackService::class.java).setAction("STOP"))
            tp.edit().putBoolean("on", false).apply()
            show(cur)
        } else {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 4); return
            }
            startForegroundService(Intent(this, TrackService::class.java))
            Toast.makeText(this, "Pelacakan otomatis dimulai", Toast.LENGTH_SHORT).show()
            tp.edit().putBoolean("on", true).apply()
            show(cur)
        }
    }

    private fun placeMenu(pl: Pl) {
        dlg().setItems(arrayOf("Ubah nama", "Hapus")) { _, w ->
            if (w == 0) {
                val et = EditText(this).apply { setText(pl.name) }
                val f = form(); f.addView(et)
                dlg().setTitle("Nama tempat").setView(f).setPositiveButton("Simpan") { _, _ ->
                    val nn = et.text.toString().trim()
                    if (nn.isNotEmpty()) { Places.save(this, Places.all(this).map { if (it.t == pl.t && it.lat == pl.lat) it.copy(name = nn) else it }); show(cur) }
                }.setNegativeButton("Batal", null).show()
            } else { Places.save(this, Places.all(this).filter { !(it.t == pl.t && it.lat == pl.lat) }); show(cur) }
        }.show()
    }

    private fun upd(x: Item) { Store.save(this, Store.all(this).map { if (it.id == x.id) x else it }); Sched.set(this, x) }
    private fun del(x: Item) { Store.save(this, Store.all(this).filter { it.id != x.id }); Sched.cancel(this, x.id); show(cur) }
    private fun put(x: Item) { Store.save(this, Store.all(this) + x); Sched.set(this, x) }

    private fun speak(et: EditText) {
        target = et
        try {
            startActivityForResult(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
                .putExtra(RecognizerIntent.EXTRA_PROMPT, "Silakan bicara"), 77)
        } catch (e: Exception) {
            Toast.makeText(this, "Pengenal suara tidak tersedia di HP ini", Toast.LENGTH_LONG).show()
        }
    }

    override fun onActivityResult(r: Int, res: Int, d: Intent?) {
        super.onActivityResult(r, res, d)
        if (r == 88 && res == RESULT_OK) d?.data?.let { photoDialog(it) }
        if (r == 89) { if (res == RESULT_OK && File(filesDir, camName).length() > 0L) finishPhoto(camName) else File(filesDir, camName).delete() }
        if (r == 77 && res == RESULT_OK) {
            val s = d?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (s != null) target?.let { it.setText((it.text.toString() + " " + s).trim()) }
        }
    }

    private fun form() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }

    private fun addItem() {
        val l = form()
        val t = EditText(this).apply { hint = "Nama kegiatan" }
        l.addView(t)
        l.addView(Button(this).apply { text = "Bicara (suara ke teks)"; setOnClickListener { speak(t) } })
        val tp = TimePicker(this).apply { setIs24HourView(true) }
        val sp = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, Groups.all(this@MainActivity).toTypedArray()) }
        val al = CheckBox(this).apply { text = "Alarm keras (bukan sekadar pengingat)"; isChecked = true }
        var mask = 0
        l.addView(tp); l.addView(sp); l.addView(al)
        l.addView(tv("Ulangi pada hari (kosong = sekali)", 12f, MU), lp(8))
        l.addView(dayRow(0) { mask = it })
        dlg().setTitle("Kegiatan baru").setView(ScrollView(this).apply { addView(l) })
            .setPositiveButton("Simpan") { _, _ ->
                if (t.text.isNotBlank()) {
                    put(Item(System.currentTimeMillis() % 1_000_000_000L, t.text.toString().trim(), tp.hour, tp.minute, mask, 0L, al.isChecked, true, sp.selectedItem.toString()))
                    show(cur)
                }
            }.setNegativeButton("Batal", null).show()
    }

    private fun writeJ() {
        val l = form()
        val et = EditText(this).apply { hint = "Tulis catatan hari ini..."; minLines = 4; gravity = Gravity.TOP }
        val sp = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("Senang", "Biasa", "Lelah", "Sedih")) }
        l.addView(et); l.addView(sp)
        l.addView(Button(this).apply { text = "Bicara (suara ke teks)"; setOnClickListener { speak(et) } })
        dlg().setTitle("Jurnal baru").setView(ScrollView(this).apply { addView(l) })
            .setPositiveButton("Simpan") { _, _ ->
                if (et.text.isNotBlank()) {
                    val now = System.currentTimeMillis()
                    Jrn.save(this, Jrn.all(this) + Jr(now, now, sp.selectedItem.toString(), et.text.toString().trim()))
                    show(cur)
                }
            }.setNegativeButton("Batal", null).show()
    }

    private fun addGroup() {
        val et = EditText(this).apply { hint = "Nama kelompok" }
        val l = form(); l.addView(et)
        dlg().setTitle("Kelompok baru").setView(l)
            .setPositiveButton("Simpan") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty() && n !in Groups.all(this)) { Groups.save(this, Groups.all(this) + n); show(cur) }
            }.setNegativeButton("Batal", null).show()
    }

    private fun assistant() {
        val l = form()
        val et = EditText(this).apply { hint = "mis. besok jam 7 olahraga, jam 9 kuliah"; minLines = 3; gravity = Gravity.TOP }
        l.addView(et)
        l.addView(Button(this).apply { text = "Bicara (suara ke teks)"; setOnClickListener { speak(et) } })
        dlg().setTitle("Asisten jadwal").setView(l)
            .setPositiveButton("Susun") { _, _ -> preview(et.text.toString()) }.setNegativeButton("Batal", null).show()
    }

    private fun preview(s: String) {
        val xs = Parser.parse(s)
        if (xs.isEmpty()) {
            dlg().setMessage("Belum ada jam yang terbaca. Contoh: besok jam 7 olahraga, jam 9 kuliah").setPositiveButton("OK", null).show()
            return
        }
        val m = xs.joinToString("\n") { "%02d.%02d  %s".format(it.hour, it.minute, it.title) }
        dlg().setTitle("Draf jadwal").setMessage(m)
            .setPositiveButton("Setujui dan pasang alarm") { _, _ -> xs.forEach { put(it) }; show(cur) }
            .setNegativeButton("Batal", null).show()
    }
}

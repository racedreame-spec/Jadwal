package app.jadwal

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.text.InputType
import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import java.io.File
import android.view.Gravity
import android.view.View
import android.view.animation.Animation
import android.view.animation.DecelerateInterpolator
import android.view.animation.ScaleAnimation
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

private val BG = 0xFF0B1020.toInt()
private val FG = 0xFFF1F5F9.toInt()
private val MU = 0xFFA5B0C4.toInt()
private val CY = 0xFF67E8F9.toInt()
private val GR = intArrayOf(0xFF6D4AFF.toInt(), 0xFF0891B2.toInt())

class Ring(c: Context) : View(c) {
    private var shown = 0f
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 24f; color = 0x1FFFFFFF }
    private val fg = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 24f; strokeCap = Paint.Cap.ROUND; color = 0xFF22D3EE.toInt() }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; textSize = 48f; typeface = Typeface.DEFAULT_BOLD }
    fun go(t: Float) {
        ValueAnimator.ofFloat(0f, t).apply {
            duration = 1200
            interpolator = DecelerateInterpolator()
            addUpdateListener { shown = it.animatedValue as Float; invalidate() }
        }.start()
    }
    override fun onDraw(cv: Canvas) {
        val r = RectF(20f, 20f, width - 20f, height - 20f)
        cv.drawArc(r, 0f, 360f, false, bg)
        cv.drawArc(r, -90f, 360f * shown, false, fg)
        cv.drawText("${(shown * 100).toInt()}%", width / 2f, height / 2f + 16f, tp)
    }
}

class LL(val f: (Location) -> Unit) : LocationListener {
    override fun onLocationChanged(l: Location) { f(l) }
    override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
    override fun onProviderEnabled(p: String) {}
    override fun onProviderDisabled(p: String) {}
}

class MainActivity : Activity() {
    private lateinit var content: FrameLayout
    private val navIv = mutableListOf<ImageView>()
    private val navTv = mutableListOf<TextView>()
    private var cur = 0
    private var target: EditText? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun tv(t: String, sp: Float, col: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sp * 0.9f; setTextColor(col); if (bold) setTypeface(null, Typeface.BOLD)
    }
    private fun box(col: Int, r: Int, st: Int = 0) = GradientDrawable().apply {
        setColor(col); cornerRadius = dp(r).toFloat(); if (st != 0) setStroke(dp(1), st)
    }
    private fun grad(r: Int) = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, GR).apply { cornerRadius = dp(r).toFloat() }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(Color.WHITE); background = grad(16); setOnClickListener { f() }
    }
    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) }
    private fun glass() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = box(0x12FFFFFF, 20, 0x1FFFFFFF); setPadding(dp(16), dp(14), dp(16), dp(14))
    }
    private fun page() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(52), dp(20), dp(24)) }
    private fun View.rise(i: Int) {
        alpha = 0f; translationY = dp(14).toFloat()
        animate().alpha(1f).translationY(0f).setStartDelay(i * 70L).setDuration(450).start()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG; window.navigationBarColor = BG
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        Notif.channels(this)
        val root = FrameLayout(this).apply { background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFF1B1446.toInt(), BG, BG)) }
        content = FrameLayout(this)
        root.addView(content, FrameLayout.LayoutParams(-1, -1).apply { bottomMargin = dp(96) })
        root.addView(nav(), FrameLayout.LayoutParams(-1, dp(68), Gravity.BOTTOM).apply { setMargins(dp(16), 0, dp(16), dp(18)) })
        setContentView(root)
        show(0)
    }

    override fun onResume() { super.onResume(); show(cur) }

    private fun nav(): View {
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = box(0xF0121830.toInt(), 34, 0x24FFFFFF) }
        val names = arrayOf("Hari Ini", "Jurnal", "", "Grafik", "Menu")
        val icons = intArrayOf(R.drawable.ic_cal, R.drawable.ic_book, R.drawable.ic_spark, R.drawable.ic_chart, R.drawable.ic_grid)
        for (i in 0..4) {
            if (i == 2) {
                val orb = FrameLayout(this).apply { background = grad(30); setOnClickListener { assistant() } }
                orb.addView(ImageView(this).apply { setImageResource(R.drawable.ic_spark); setColorFilter(Color.WHITE) }, FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER))
                ObjectAnimator.ofPropertyValuesHolder(orb, PropertyValuesHolder.ofFloat("scaleX", 1f, 1.1f), PropertyValuesHolder.ofFloat("scaleY", 1f, 1.1f)).apply {
                    duration = 1100; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE
                }.start()
                bar.addView(orb, LinearLayout.LayoutParams(dp(60), dp(60)).apply { marginStart = dp(8); marginEnd = dp(8) })
                navIv.add(ImageView(this)); navTv.add(TextView(this))
                continue
            }
            val item = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setOnClickListener { show(if (i > 2) i - 1 else i) } }
            val iv = ImageView(this).apply { setImageResource(icons[i]) }
            val t = tv(names[i], 11f, MU, true).apply { gravity = Gravity.CENTER }
            item.addView(iv, LinearLayout.LayoutParams(dp(24), dp(24)))
            item.addView(t, lp(2))
            bar.addView(item, LinearLayout.LayoutParams(0, -1, 1f))
            navIv.add(iv); navTv.add(t)
        }
        return bar
    }

    private fun show(n: Int) {
        cur = n
        tick?.let { h.removeCallbacks(it) }
        content.removeAllViews()
        val pg = when (n) { 0 -> today(); 1 -> journal(); 2 -> chart(); 3 -> menu(); 4 -> timer(); 5 -> consist(); 6 -> olahraga(); 7 -> perjalanan(); 8 -> kenangan(); else -> kontrol() }
        content.addView(ScrollView(this).apply { addView(pg); isVerticalScrollBarEnabled = false })
        for (i in 0..4) {
            if (i == 2) continue
            val on = i == (if (n == 2) 3 else if (n >= 3) 4 else n)
            navIv[i].setColorFilter(if (on) CY else MU)
            navTv[i].setTextColor(if (on) CY else MU)
        }
    }

    private fun today(): LinearLayout {
        val p = page()
        p.addView(tv(SimpleDateFormat("EEEE, d MMMM", Locale("id", "ID")).format(Date()), 13f, MU))
        p.addView(tv("Hari Ini", 30f, FG, true))
        val all = Store.all(this).sortedWith(compareBy<Item>({ it.hour }, { it.minute }))
        val dn = all.count { Hist.isDone(this, it.id) }
        val hero = glass().apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val ring = Ring(this)
        hero.addView(ring, LinearLayout.LayoutParams(dp(96), dp(96)))
        val tx = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), 0, 0, 0) }
        tx.addView(tv("Progres hari ini", 13f, MU))
        tx.addView(tv("$dn dari ${all.size} selesai", 20f, FG, true))
        tx.addView(tv("Streak ${Hist.streak(this)} hari", 13f, CY, true))
        hero.addView(tx)
        p.addView(hero, lp(16)); hero.rise(0)
        ring.go(if (all.isEmpty()) 0f else dn.toFloat() / all.size)
        val br = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        br.addView(btn("+ Kegiatan") { addItem() }, LinearLayout.LayoutParams(0, -2, 1f))
        br.addView(btn("Asisten") { assistant() }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(10) })
        br.addView(btn("Timer") { show(4) }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(10) })
        p.addView(br, lp(12))
        if (all.isEmpty()) p.addView(tv("Belum ada kegiatan. Tambahkan lewat tombol di atas.", 14f, MU), lp(20))
        all.forEachIndexed { i, x -> val v = itemRow(x); v.rise(i + 1); p.addView(v, lp(10)) }
        return p
    }

    private fun itemRow(x: Item): View {
        val done = Hist.isDone(this, x.id)
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = box(0x12FFFFFF, 18, 0x1FFFFFFF); setPadding(dp(14), dp(12), dp(14), dp(12)) }
        r.addView(tv("%02d.%02d".format(x.hour, x.minute), 15f, FG, true).apply { minWidth = dp(58) })
        r.addView(View(this).apply { background = box(Groups.color(this@MainActivity, x.grp), 6) }, LinearLayout.LayoutParams(dp(10), dp(10)).apply { marginEnd = dp(10) })
        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val ti = tv(x.title, 16f, if (x.on) FG else MU, true)
        if (done) ti.paintFlags = ti.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
        mid.addView(ti)
        mid.addView(tv(x.grp + " - " + (if (x.alarm) "alarm" else "pengingat") + (if (x.on) "" else " - nonaktif"), 12f, MU))
        r.addView(mid, LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(tv(if (done) "Selesai" else "Tandai", 12f, if (done) CY else MU, true).apply {
            setPadding(dp(10), dp(10), dp(4), dp(10)); setOnClickListener { Hist.toggle(this@MainActivity, x); show(cur) }
        })
        r.setOnLongClickListener {
            AlertDialog.Builder(this).setItems(arrayOf(if (x.on) "Nonaktifkan" else "Aktifkan", "Hapus")) { _, w ->
                if (w == 0) { upd(x.copy(on = !x.on)); show(cur) } else del(x)
            }.show()
            true
        }
        return r
    }

    private fun journal(): LinearLayout {
        val p = page()
        p.addView(tv("Jurnal", 30f, FG, true))
        val d = Hist.day()
        val dn = Hist.all(this).count { it.d == d }
        val js = Jrn.all(this)
        val nowD = js.count { Hist.day(it.t) == d }
        val rec = glass(); rec.rise(0)
        rec.addView(tv("Rekap hari ini", 13f, MU))
        rec.addView(tv("$dn kegiatan selesai dari ${Store.all(this).size}, $nowD catatan jurnal", 15f, FG, true), lp(4))
        p.addView(rec, lp(14))
        p.addView(btn("+ Tulis jurnal") { writeJ() }, lp(12))
        if (js.isEmpty()) p.addView(tv("Belum ada catatan. Ketuk tombol di atas, lalu tulis atau bicara.", 14f, MU), lp(20))
        js.forEachIndexed { i, j ->
            val c = glass(); c.rise(i + 1)
            c.addView(tv(SimpleDateFormat("d MMM, HH.mm", Locale("id", "ID")).format(Date(j.t)) + "  -  " + j.mood, 12f, CY, true))
            c.addView(tv(j.text, 15f, FG), lp(6))
            c.setOnLongClickListener {
                AlertDialog.Builder(this).setMessage("Hapus catatan ini?").setPositiveButton("Hapus") { _, _ ->
                    Jrn.save(this, Jrn.all(this).filter { it.id != j.id }); show(cur)
                }.setNegativeButton("Batal", null).show()
                true
            }
            p.addView(c, lp(10))
        }
        return p
    }

    private fun chart(): LinearLayout {
        val p = page()
        p.addView(tv("Grafik", 30f, FG, true))
        val recs = Hist.all(this)
        val loc = Locale("id", "ID")
        val cal = Calendar.getInstance(); cal.add(Calendar.DAY_OF_YEAR, -6)
        val days = (0..6).map { val t = cal.timeInMillis; cal.add(Calendar.DAY_OF_YEAR, 1); t }
        val cnt = days.map { t -> recs.count { it.d == Hist.day(t) } }
        val mx = (cnt.maxOrNull() ?: 0).coerceAtLeast(1)
        val c1 = glass(); c1.rise(0)
        c1.addView(tv("Kegiatan selesai, 7 hari terakhir", 14f, FG, true))
        val bars = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM }
        days.forEachIndexed { i, t ->
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
            col.addView(tv(cnt[i].toString(), 11f, MU), LinearLayout.LayoutParams(-2, -2))
            val b = View(this).apply { background = box(if (i == 6) 0xFF22D3EE.toInt() else 0x668B6CFF, 8) }
            col.addView(b, LinearLayout.LayoutParams(dp(26), dp(6) + dp(90) * cnt[i] / mx).apply { topMargin = dp(4); bottomMargin = dp(4) })
            b.startAnimation(ScaleAnimation(1f, 1f, 0f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 1f).apply { duration = 700; startOffset = i * 80L; interpolator = DecelerateInterpolator() })
            col.addView(tv(SimpleDateFormat("EEE", loc).format(Date(t)), 11f, MU), LinearLayout.LayoutParams(-2, -2))
            bars.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        }
        c1.addView(bars, LinearLayout.LayoutParams(-1, dp(150)).apply { topMargin = dp(12) })
        val week = days.map { Hist.day(it) }.toSet()
        val byG = recs.filter { it.d in week }.groupingBy { it.g }.eachCount().entries.sortedByDescending { it.value }
        val c2 = glass(); c2.rise(1)
        c2.addView(tv("Per kelompok, 7 hari terakhir", 14f, FG, true))
        if (byG.isEmpty()) c2.addView(tv("Belum ada data. Tandai kegiatan selesai di Hari Ini.", 13f, MU), lp(8))
        val tot = byG.sumOf { it.value }.coerceAtLeast(1)
        byG.forEachIndexed { i, e ->
            c2.addView(tv(e.key + "  -  " + e.value, 13f, FG, true), lp(12))
            val tr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; weightSum = 100f; background = box(0x1AFFFFFF, 4) }
            val bar = View(this).apply { background = box(Groups.color(this@MainActivity, e.key), 4) }
            tr.addView(bar, LinearLayout.LayoutParams(0, dp(8), (100f * e.value / tot).coerceAtLeast(2f)))
            bar.startAnimation(ScaleAnimation(0f, 1f, 1f, 1f, Animation.RELATIVE_TO_SELF, 0f, Animation.RELATIVE_TO_SELF, 0.5f).apply { duration = 800; startOffset = i * 100L })
            c2.addView(tr, lp(6).apply { height = dp(8) })
        }
        fun tile(v: String, l: String): View { val g = glass(); g.addView(tv(v, 24f, CY, true)); g.addView(tv(l, 12f, MU)); g.rise(2); return g }
        val tl = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tl.addView(tile("${Hist.streak(this)} hari", "Streak"), LinearLayout.LayoutParams(0, -2, 1f))
        tl.addView(tile("${cnt.sum()}", "Selesai 7 hari"), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12) })
        p.addView(c1, lp(14)); p.addView(c2, lp(12)); p.addView(tl, lp(12))
        return p
    }

    private fun menu(): LinearLayout {
        val p = page()
        p.addView(tv("Menu", 30f, FG, true))
        val items = Store.all(this)
        val c = glass(); c.rise(0)
        c.addView(tv("Kelompok kegiatan", 14f, FG, true))
        Groups.all(this).forEach { g ->
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(10), 0, dp(10)) }
            r.addView(View(this).apply { background = box(Groups.color(this@MainActivity, g), 6) }, LinearLayout.LayoutParams(dp(10), dp(10)).apply { marginEnd = dp(10) })
            r.addView(tv(g, 15f, FG), LinearLayout.LayoutParams(0, -2, 1f))
            r.addView(tv("${items.count { it.grp == g }} kegiatan", 12f, MU))
            r.setOnLongClickListener {
                if (g != "Umum") AlertDialog.Builder(this).setMessage("Hapus kelompok $g?").setPositiveButton("Hapus") { _, _ ->
                    Groups.save(this, Groups.all(this) - g); show(cur)
                }.setNegativeButton("Batal", null).show()
                true
            }
            c.addView(r)
        }
        c.addView(tv("Tahan lama untuk menghapus kelompok.", 12f, MU), lp(4))
        c.addView(btn("+ Tambah kelompok") { addGroup() }, lp(10))
        p.addView(c, lp(14))
        p.addView(btn("Izin alarm dan baterai (Setelan HP)") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }, lp(12))
        val tiles = listOf("Timer fokus" to 4, "Konsistensi" to 5, "Olahraga" to 6, "Perjalanan" to 7, "Kenangan" to 8, "Kontrol Ponsel" to 9)
        for (r in 0..2) {
            val tr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (ci in 0..1) {
                val t = tiles[r * 2 + ci]
                tr.addView(btn(t.first) { show(t.second) }, LinearLayout.LayoutParams(0, -2, 1f).apply { if (ci == 1) marginStart = dp(10) })
            }
            p.addView(tr, lp(if (r == 0) 12 else 8))
        }
        p.addView(tv("Tahap berikutnya: pemblokiran aplikasi saat Mode Fokus.", 13f, MU), lp(16))
        return p
    }

    private val h = android.os.Handler(android.os.Looper.getMainLooper())
    private var tick: Runnable? = null

    override fun onPause() { super.onPause(); tick?.let { h.removeCallbacks(it) } }

    private fun timer(): LinearLayout {
        val p = page()
        p.addView(tv("Timer", 30f, FG, true))
        val big = tv("00:00", 52f, FG, true).apply { gravity = Gravity.CENTER }
        val info = tv("", 13f, MU).apply { gravity = Gravity.CENTER }
        val card = glass(); card.rise(0)
        card.addView(big, lp(8)); card.addView(info, lp(4))
        p.addView(card, lp(14))
        val items = Store.all(this)
        val names = arrayOf("Tanpa kegiatan") + items.map { it.title }
        val sp = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, names)
            background = box(0xFFE2E8F0.toInt(), 12)
        }
        val et = EditText(this).apply {
            setText("25"); inputType = InputType.TYPE_CLASS_NUMBER; setTextColor(FG); gravity = Gravity.CENTER; textSize = 20f
        }
        val pr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(25, 45, 60).forEachIndexed { i, m ->
            pr.addView(btn("$m mnt") { et.setText(m.toString()) }, LinearLayout.LayoutParams(0, -2, 1f).apply { if (i > 0) marginStart = dp(8) })
        }
        p.addView(tv("Durasi (menit)", 13f, MU), lp(16))
        p.addView(et, lp(0)); p.addView(pr, lp(4))
        p.addView(tv("Kaitkan ke kegiatan (otomatis ditandai selesai)", 13f, MU), lp(14))
        p.addView(sp, lp(6))
        p.addView(btn("Mulai timer") {
            val m = et.text.toString().toIntOrNull() ?: 0
            if (m in 1..600) {
                TimerStore.start(this, m, if (sp.selectedItemPosition > 0) items[sp.selectedItemPosition - 1].id else 0L)
                show(cur)
            }
        }, lp(16))
        p.addView(btn("Batalkan timer") { TimerStore.cancel(this); show(cur) }, lp(8))
        val upd = object : Runnable {
            override fun run() {
                val left = TimerStore.end(this@MainActivity) - System.currentTimeMillis()
                if (TimerStore.end(this@MainActivity) > 0L && left > 0L) {
                    val s = left / 1000
                    big.text = "%02d:%02d".format(s / 60, s % 60)
                    info.text = "Sedang berjalan. Alarm berbunyi saat selesai."
                    h.postDelayed(this, 500)
                } else {
                    big.text = "00:00"
                    info.text = "Hari ini: ${TimerStore.minutesToday(this@MainActivity)} menit fokus"
                }
            }
        }
        tick = upd
        upd.run()
        return p
    }

    private fun consist(): LinearLayout {
        val p = page()
        p.addView(tv("Konsistensi", 30f, FG, true))
        val recs = Hist.all(this)
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        fun ep(d: String): Int = Math.round((fmt.parse(d)?.time ?: 0L) / 86400000.0).toInt()
        val today = ep(Hist.day())
        val dset = recs.map { ep(it.d) }.toSet()
        val s14 = (0..13).count { (today - it) in dset }
        val c1 = glass(); c1.rise(0)
        c1.addView(tv("Skor 14 hari terakhir", 13f, MU))
        c1.addView(tv("${s14 * 100 / 14}%  ($s14 dari 14 hari ada kegiatan selesai)", 17f, FG, true), lp(4))
        for (r in 0..3) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (ci in 0..6) {
                val back = 27 - (r * 7 + ci)
                val on = (today - back) in dset
                val cell = View(this).apply { background = box(if (on) 0xFF22D3EE.toInt() else 0x1FFFFFFF, 6) }
                row.addView(cell, LinearLayout.LayoutParams(0, dp(30), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
                cell.alpha = 0f
                cell.animate().alpha(1f).setStartDelay((r * 7 + ci) * 25L).setDuration(300).start()
            }
            c1.addView(row, lp(if (r == 0) 12 else 0))
        }
        c1.addView(tv("Kotak terang = ada kegiatan selesai pada hari itu (28 hari)", 11f, MU), lp(8))
        p.addView(c1, lp(14))
        val items = Store.all(this)
        if (items.isEmpty()) p.addView(tv("Belum ada kegiatan.", 14f, MU), lp(16))
        var k = 1
        items.forEach { x ->
            val ds = recs.filter { it.id == x.id }.map { ep(it.d) }.distinct().sorted()
            val c = glass(); c.rise(k++)
            c.addView(tv(x.title, 15f, FG, true))
            val msg: String
            val col: Int
            if (ds.size < 2) {
                msg = "Butuh data: tandai selesai beberapa kali"; col = MU
            } else {
                val gaps = ds.zipWithNext { a, b -> b - a }.sorted()
                val typ = gaps[gaps.size / 2].coerceAtLeast(1)
                val since = today - ds.last()
                if (since <= typ) { msg = "Biasanya tiap $typ hari, terakhir $since hari lalu. Sesuai."; col = 0xFF34D399.toInt() }
                else { msg = "Biasanya tiap $typ hari, sudah $since hari. Terlambat ${since - typ} hari."; col = 0xFFFBBF24.toInt() }
            }
            c.addView(tv(msg, 13f, col, true), lp(4))
            p.addView(c, lp(10))
        }
        return p
    }

    private var running = false
    private var woStart = 0L
    private var woM = 0f
    private var lastL: Location? = null
    private var woType = "Lari"
    private var pendingHere: ((Location) -> Unit)? = null
    private val ll = LL { l -> if (l.accuracy < 35f) { lastL?.let { woM += it.distanceTo(l) }; lastL = l } }
    private val soc = setOf("com.whatsapp", "com.whatsapp.w4b", "com.instagram.android", "com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.facebook.katana", "com.facebook.lite", "com.twitter.android", "com.facebook.orca", "org.telegram.messenger", "com.snapchat.android", "com.instagram.barcelona", "com.google.android.youtube")

    override fun onDestroy() {
        super.onDestroy()
        if (running) try { getSystemService(LocationManager::class.java).removeUpdates(ll) } catch (e: Exception) {}
    }

    override fun onRequestPermissionsResult(rc: Int, ps: Array<out String>, gr: IntArray) {
        super.onRequestPermissionsResult(rc, ps, gr)
        if (gr.any { it == PackageManager.PERMISSION_GRANTED }) {
            if (rc == 2) startWo()
            if (rc == 3) { pendingHere?.let { here(it) }; pendingHere = null }
        }
    }

    private fun pace(x: Float): String = "%d'%02d\"".format((x / 60).toInt(), (x % 60).toInt())
    private fun fmtMs(ms: Long): String { val m = ms / 60000; return if (m >= 60) "${m / 60} j ${m % 60} m" else "$m m" }

    private fun startWo() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 2); return
        }
        val lm = getSystemService(LocationManager::class.java)
        if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) { Toast.makeText(this, "Nyalakan GPS dulu", Toast.LENGTH_LONG).show(); return }
        woM = 0f; lastL = null; woStart = System.currentTimeMillis(); running = true
        lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1500L, 3f, ll)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        show(cur)
    }

    private fun stopWo() {
        getSystemService(LocationManager::class.java).removeUpdates(ll)
        window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val s = ((System.currentTimeMillis() - woStart) / 1000).toInt()
        running = false
        if (s >= 10) Wos.add(this, Wo(woStart, woType, s, woM))
        show(cur)
    }

    private fun olahraga(): LinearLayout {
        val p = page()
        p.addView(tv("Olahraga", 30f, FG, true))
        val card = glass(); card.rise(0)
        val big = tv("00:00:00", 40f, FG, true).apply { gravity = Gravity.CENTER }
        val sub = tv("0.00 km   0.0 km/jam   pace --", 13f, MU).apply { gravity = Gravity.CENTER }
        card.addView(big, lp(6)); card.addView(sub, lp(6))
        p.addView(card, lp(14))
        val sp = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("Lari", "Jalan", "Sepeda"))
            background = box(0xFFE2E8F0.toInt(), 12)
        }
        if (!running) p.addView(sp, lp(12))
        p.addView(btn(if (running) "Berhenti dan simpan" else "Mulai") {
            if (running) stopWo() else { woType = sp.selectedItem.toString(); startWo() }
        }, lp(10))
        p.addView(tv("Biarkan aplikasi tetap terbuka selama berolahraga. Layar dijaga menyala.", 12f, MU), lp(6))
        val ws = Wos.all(this)
        val w7 = ws.filter { it.t >= System.currentTimeMillis() - 7 * 86400000L }
        val c2 = glass(); c2.rise(1)
        c2.addView(tv("7 hari terakhir", 14f, FG, true))
        c2.addView(tv("${w7.size} sesi, %.2f km, ${w7.sumOf { it.secs } / 60} menit".format(w7.sumOf { it.m.toDouble() } / 1000), 14f, FG), lp(6))
        val far = ws.maxByOrNull { it.m }
        val fast = ws.filter { it.m > 500f && it.secs > 0 }.maxByOrNull { it.m / it.secs }
        val rec = if (far == null) "Belum ada rekor." else "Terjauh: %.2f km (${far.type})".format(far.m / 1000) + (if (fast != null) "  -  Tercepat: %.1f km/jam".format(fast.m / fast.secs * 3.6f) else "")
        c2.addView(tv(rec, 13f, CY, true), lp(6))
        p.addView(c2, lp(12))
        ws.take(5).forEachIndexed { i, w ->
            val c = glass(); c.rise(i + 2)
            c.addView(tv(SimpleDateFormat("d MMM, HH.mm", Locale("id", "ID")).format(Date(w.t)) + "  -  " + w.type, 12f, CY, true))
            val km = w.m / 1000f
            c.addView(tv("%.2f km   %02d:%02d   pace %s".format(km, w.secs / 60, w.secs % 60, if (km > 0.02f) pace(w.secs / km) else "--"), 15f, FG, true), lp(4))
            p.addView(c, lp(10))
        }
        val upd = object : Runnable {
            override fun run() {
                if (running) {
                    val s = ((System.currentTimeMillis() - woStart) / 1000).toInt()
                    big.text = "%02d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
                    val km = woM / 1000f
                    val v = if (s > 0) km / s * 3600f else 0f
                    sub.text = "%.2f km   %.1f km/jam   pace %s".format(km, v, if (km > 0.02f) pace(s / km) else "--")
                    h.postDelayed(this, 1000)
                }
            }
        }
        tick = upd
        upd.run()
        return p
    }

    private fun here(cb: (Location) -> Unit) {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            pendingHere = cb
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 3)
            return
        }
        val lm = getSystemService(LocationManager::class.java)
        val best = listOf("gps", "network", "passive").mapNotNull { try { lm.getLastKnownLocation(it) } catch (e: Exception) { null } }.maxByOrNull { it.time }
        if (best != null && System.currentTimeMillis() - best.time < 120000L) { cb(best); return }
        val prov = if (lm.isProviderEnabled("gps")) "gps" else if (lm.isProviderEnabled("network")) "network" else null
        if (prov == null) { Toast.makeText(this, "Nyalakan lokasi/GPS dulu", Toast.LENGTH_LONG).show(); return }
        Toast.makeText(this, "Mencari lokasi...", Toast.LENGTH_SHORT).show()
        lm.requestSingleUpdate(prov, LL { l -> cb(l) }, null)
    }

    private fun mark() {
        here { l ->
            Thread {
                var n = "%.4f, %.4f".format(l.latitude, l.longitude)
                try {
                    if (android.location.Geocoder.isPresent()) {
                        val a = android.location.Geocoder(this, Locale("id", "ID")).getFromLocation(l.latitude, l.longitude, 1)
                        if (!a.isNullOrEmpty()) n = a[0].getAddressLine(0) ?: n
                    }
                } catch (e: Exception) {}
                runOnUiThread { nameDialog(l, n) }
            }.start()
        }
    }

    private fun nameDialog(l: Location, n: String) {
        val et = EditText(this).apply { setText(n) }
        val f = form(); f.addView(et)
        AlertDialog.Builder(this).setTitle("Nama tempat").setView(f)
            .setPositiveButton("Simpan") { _, _ ->
                Places.save(this, Places.all(this) + Pl(System.currentTimeMillis(), l.latitude, l.longitude, et.text.toString().trim().ifEmpty { n }))
                show(cur)
            }.setNegativeButton("Batal", null).show()
    }

    private fun perjalanan(): LinearLayout {
        val p = page()
        p.addView(tv("Perjalanan", 30f, FG, true))
        p.addView(tv("Ketuk tombol saat tiba di suatu tempat untuk mencatat singgahan Anda.", 13f, MU), lp(4))
        p.addView(btn("Tandai lokasi sekarang") { mark() }, lp(12))
        val all = Places.all(this)
        if (all.isEmpty()) p.addView(tv("Belum ada tempat tercatat.", 14f, MU), lp(16))
        val fd = SimpleDateFormat("EEEE, d MMMM", Locale("id", "ID"))
        val ft = SimpleDateFormat("HH.mm", Locale.US)
        var idx = 1
        all.groupBy { Hist.day(it.t) }.entries.sortedByDescending { it.key }.take(7).forEach { e ->
            val sorted = e.value.sortedBy { it.t }
            var tot = 0f
            val c = glass(); c.rise(idx++)
            val head = tv("", 14f, FG, true)
            c.addView(head)
            sorted.forEachIndexed { i, pl ->
                var leg = ""
                if (i > 0) {
                    val r = FloatArray(1)
                    Location.distanceBetween(sorted[i - 1].lat, sorted[i - 1].lng, pl.lat, pl.lng, r)
                    tot += r[0]
                    leg = "  (+%.1f km)".format(r[0] / 1000)
                }
                val row = tv(ft.format(Date(pl.t)) + "  " + pl.name + leg, 13f, FG)
                row.setOnLongClickListener {
                    AlertDialog.Builder(this).setMessage("Hapus tempat ini?").setPositiveButton("Hapus") { _, _ ->
                        Places.save(this, Places.all(this).filter { it.t != pl.t }); show(cur)
                    }.setNegativeButton("Batal", null).show()
                    true
                }
                c.addView(row, lp(8))
            }
            head.text = fd.format(Date(sorted[0].t)) + "  -  ${sorted.size} tempat, %.1f km".format(tot / 1000)
            p.addView(c, lp(12))
        }
        return p
    }

    private fun thumb(path: String): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, o)
        var s = 1
        while (o.outWidth / (s * 2) >= 800) s *= 2
        val bm = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s }) ?: return null
        return try {
            val rot = when (android.media.ExifInterface(path).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
            if (rot != 0f) Bitmap.createBitmap(bm, 0, 0, bm.width, bm.height, Matrix().apply { postRotate(rot) }, true) else bm
        } catch (e: Exception) { bm }
    }

    private fun kenangan(): LinearLayout {
        val p = page()
        p.addView(tv("Kenangan", 30f, FG, true))
        p.addView(btn("+ Tambah foto dari galeri") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE), 88)
        }, lp(12))
        val ms = Mems.all(this)
        if (ms.isEmpty()) p.addView(tv("Belum ada foto. Tambahkan kenangan dari setiap kegiatan.", 14f, MU), lp(16))
        ms.forEachIndexed { i, m ->
            val c = glass(); c.rise(i + 1)
            val bm = thumb(File(filesDir, m.file).path)
            if (bm != null) c.addView(ImageView(this).apply { setImageBitmap(bm); scaleType = ImageView.ScaleType.CENTER_CROP }, LinearLayout.LayoutParams(-1, dp(200)))
            c.addView(tv(m.cap.ifEmpty { "Tanpa keterangan" }, 15f, FG, true), lp(8))
            c.addView(tv(SimpleDateFormat("d MMM yyyy, HH.mm", Locale("id", "ID")).format(Date(m.t)) + (if (m.link.isNotEmpty()) "  -  " + m.link else ""), 12f, MU), lp(2))
            c.setOnLongClickListener {
                AlertDialog.Builder(this).setMessage("Hapus kenangan ini?").setPositiveButton("Hapus") { _, _ ->
                    File(filesDir, m.file).delete()
                    Mems.save(this, Mems.all(this).filter { it.id != m.id }); show(cur)
                }.setNegativeButton("Batal", null).show()
                true
            }
            p.addView(c, lp(12))
        }
        return p
    }

    private fun photoDialog(u: Uri) {
        val name = "m" + System.currentTimeMillis() + ".jpg"
        try {
            contentResolver.openInputStream(u)?.use { i -> File(filesDir, name).outputStream().use { o -> i.copyTo(o) } }
        } catch (e: Exception) { Toast.makeText(this, "Foto gagal dibaca", Toast.LENGTH_LONG).show(); return }
        val items = Store.all(this)
        val f = form()
        val et = EditText(this).apply { hint = "Keterangan kenangan" }
        val sp = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("Tanpa kegiatan") + items.map { it.title }) }
        f.addView(et); f.addView(sp)
        AlertDialog.Builder(this).setTitle("Foto baru").setView(f)
            .setPositiveButton("Simpan") { _, _ ->
                val now = System.currentTimeMillis()
                Mems.save(this, Mems.all(this) + Mm(now, now, name, et.text.toString().trim(), if (sp.selectedItemPosition > 0) items[sp.selectedItemPosition - 1].title else ""))
                show(cur)
            }.setNegativeButton("Batal") { _, _ -> File(filesDir, name).delete() }.show()
    }

    private fun hasUsage(): Boolean {
        val a = getSystemService(AppOpsManager::class.java)
        val m = if (Build.VERSION.SDK_INT >= 29) a.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
        else @Suppress("DEPRECATION") a.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
        return m == AppOpsManager.MODE_ALLOWED
    }

    private fun label(pk: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pk, 0)).toString()
    } catch (e: Exception) { pk.substringAfterLast('.') }

    private fun setLim() {
        val et = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(getSharedPreferences("ctl", MODE_PRIVATE).getInt("lim", 60).toString()) }
        val f = form(); f.addView(et)
        AlertDialog.Builder(this).setTitle("Batas media sosial (menit per hari)").setView(f)
            .setPositiveButton("Simpan") { _, _ ->
                val v = et.text.toString().toIntOrNull() ?: 0
                if (v in 5..1440) { getSharedPreferences("ctl", MODE_PRIVATE).edit().putInt("lim", v).apply(); show(cur) }
            }.setNegativeButton("Batal", null).show()
    }

    private fun kontrol(): LinearLayout {
        val p = page()
        p.addView(tv("Kontrol Ponsel", 30f, FG, true))
        if (!hasUsage()) {
            val c = glass(); c.rise(0)
            c.addView(tv("Aplikasi perlu izin akses data penggunaan untuk membaca waktu layar. Data tetap di HP Anda.", 14f, FG))
            c.addView(btn("Buka pengaturan izin") { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }, lp(10))
            p.addView(c, lp(14))
            return p
        }
        val um = getSystemService(UsageStatsManager::class.java)
        val c0 = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        val ls = um.queryAndAggregateUsageStats(c0.timeInMillis, System.currentTimeMillis()).values
            .filter { it.totalTimeInForeground > 60000L && it.packageName != packageName }.sortedByDescending { it.totalTimeInForeground }
        val total = ls.sumOf { it.totalTimeInForeground }
        val sosMs = ls.filter { it.packageName in soc }.sumOf { it.totalTimeInForeground }
        val lim = getSharedPreferences("ctl", MODE_PRIVATE).getInt("lim", 60)
        val c1 = glass(); c1.rise(0)
        c1.addView(tv("Waktu layar hari ini", 13f, MU))
        c1.addView(tv(fmtMs(total), 26f, FG, true), lp(2))
        p.addView(c1, lp(14))
        val c2 = glass(); c2.rise(1)
        c2.addView(tv("Media sosial hari ini", 13f, MU))
        c2.addView(tv(fmtMs(sosMs) + " dari batas " + lim + " menit", 17f, FG, true), lp(2))
        val pct = (sosMs * 100 / (lim * 60000L)).coerceAtMost(100L).toInt()
        val tr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; weightSum = 100f; background = box(0x1AFFFFFF, 4) }
        tr.addView(View(this).apply { background = box(if (pct >= 80) 0xFFFBBF24.toInt() else 0xFF22D3EE.toInt(), 4) }, LinearLayout.LayoutParams(0, dp(8), pct.coerceAtLeast(1).toFloat()))
        c2.addView(tr, lp(10).apply { height = dp(8) })
        if (pct >= 100) c2.addView(tv("Batas terlampaui. Coba rehat dulu dari media sosial.", 13f, 0xFFFBBF24.toInt(), true), lp(8))
        c2.addView(btn("Atur batas harian") { setLim() }, lp(10))
        p.addView(c2, lp(12))
        val c3 = glass(); c3.rise(2)
        c3.addView(tv("Aplikasi paling sering dipakai", 14f, FG, true))
        ls.take(8).forEach { u ->
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, 0) }
            r.addView(tv(label(u.packageName), 14f, FG), LinearLayout.LayoutParams(0, -2, 1f))
            r.addView(tv(fmtMs(u.totalTimeInForeground), 13f, CY, true))
            c3.addView(r)
        }
        p.addView(c3, lp(12))
        return p
    }

    private fun upd(x: Item) { Store.save(this, Store.all(this).map { if (it.id == x.id) x else it }); Sched.set(this, x) }
    private fun del(x: Item) { Store.save(this, Store.all(this).filter { it.id != x.id }); Sched.cancel(this, x.id); show(cur) }
    private fun put(x: Item) { Store.save(this, Store.all(this) + x); Sched.set(this, x) }

    private fun speak(et: EditText) {
        target = et
        try {
            startActivityForResult(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
                .putExtra(RecognizerIntent.EXTRA_PROMPT, "Silakan bicara"), 77)
        } catch (e: Exception) {
            Toast.makeText(this, "Pengenal suara tidak tersedia di HP ini", Toast.LENGTH_LONG).show()
        }
    }

    override fun onActivityResult(r: Int, res: Int, d: Intent?) {
        super.onActivityResult(r, res, d)
        if (r == 88 && res == RESULT_OK) d?.data?.let { photoDialog(it) }
        if (r == 77 && res == RESULT_OK) {
            val s = d?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (s != null) target?.let { it.setText((it.text.toString() + " " + s).trim()) }
        }
    }

    private fun form() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }

    private fun addItem() {
        val l = form()
        val t = EditText(this).apply { hint = "Nama kegiatan" }
        l.addView(t)
        l.addView(Button(this).apply { text = "Bicara (suara ke teks)"; setOnClickListener { speak(t) } })
        val tp = TimePicker(this).apply { setIs24HourView(true) }
        val sp = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, Groups.all(this@MainActivity).toTypedArray()) }
        val al = CheckBox(this).apply { text = "Alarm keras (bukan sekadar pengingat)"; isChecked = true }
        val dy = CheckBox(this).apply { text = "Ulangi setiap hari" }
        l.addView(tp); l.addView(sp); l.addView(al); l.addView(dy)
        AlertDialog.Builder(this).setTitle("Kegiatan baru").setView(ScrollView(this).apply { addView(l) })
            .setPositiveButton("Simpan") { _, _ ->
                if (t.text.isNotBlank()) {
                    put(Item(System.currentTimeMillis() % 1_000_000_000L, t.text.toString().trim(), tp.hour, tp.minute, if (dy.isChecked) 127 else 0, 0L, al.isChecked, true, sp.selectedItem.toString()))
                    show(cur)
                }
            }.setNegativeButton("Batal", null).show()
    }

    private fun writeJ() {
        val l = form()
        val et = EditText(this).apply { hint = "Tulis catatan hari ini..."; minLines = 4; gravity = Gravity.TOP }
        val sp = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("Senang", "Biasa", "Lelah", "Sedih")) }
        l.addView(et); l.addView(sp)
        l.addView(Button(this).apply { text = "Bicara (suara ke teks)"; setOnClickListener { speak(et) } })
        AlertDialog.Builder(this).setTitle("Jurnal baru").setView(ScrollView(this).apply { addView(l) })
            .setPositiveButton("Simpan") { _, _ ->
                if (et.text.isNotBlank()) {
                    val now = System.currentTimeMillis()
                    Jrn.save(this, Jrn.all(this) + Jr(now, now, sp.selectedItem.toString(), et.text.toString().trim()))
                    show(cur)
                }
            }.setNegativeButton("Batal", null).show()
    }

    private fun addGroup() {
        val et = EditText(this).apply { hint = "Nama kelompok" }
        val l = form(); l.addView(et)
        AlertDialog.Builder(this).setTitle("Kelompok baru").setView(l)
            .setPositiveButton("Simpan") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty() && n !in Groups.all(this)) { Groups.save(this, Groups.all(this) + n); show(cur) }
            }.setNegativeButton("Batal", null).show()
    }

    private fun assistant() {
        val l = form()
        val et = EditText(this).apply { hint = "mis. besok jam 7 olahraga, jam 9 kuliah"; minLines = 3; gravity = Gravity.TOP }
        l.addView(et)
        l.addView(Button(this).apply { text = "Bicara (suara ke teks)"; setOnClickListener { speak(et) } })
        AlertDialog.Builder(this).setTitle("Asisten jadwal").setView(l)
            .setPositiveButton("Susun") { _, _ -> preview(et.text.toString()) }.setNegativeButton("Batal", null).show()
    }

    private fun preview(s: String) {
        val xs = Parser.parse(s)
        if (xs.isEmpty()) {
            AlertDialog.Builder(this).setMessage("Belum ada jam yang terbaca. Contoh: besok jam 7 olahraga, jam 9 kuliah").setPositiveButton("OK", null).show()
            return
        }
        val m = xs.joinToString("\n") { "%02d.%02d  %s".format(it.hour, it.minute, it.title) }
        AlertDialog.Builder(this).setTitle("Draf jadwal").setMessage(m)
            .setPositiveButton("Setujui dan pasang alarm") { _, _ -> xs.forEach { put(it) }; show(cur) }
            .setNegativeButton("Batal", null).show()
    }
}

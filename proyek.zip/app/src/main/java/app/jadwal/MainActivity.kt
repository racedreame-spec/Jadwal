package app.jadwal

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = 0xFF0B1020.toInt()
    private val fg = 0xFFF1F5F9.toInt()
    private val mu = 0xFFA5B0C4.toInt()
    private lateinit var list: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun tv(t: String, sp: Float, col: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sp; setTextColor(col); if (bold) setTypeface(null, Typeface.BOLD)
    }
    private fun box(col: Int, r: Int) = GradientDrawable().apply { setColor(col); cornerRadius = dp(r).toFloat() }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(Color.WHITE)
        background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF6D4AFF.toInt(), 0xFF0891B2.toInt())).apply { cornerRadius = dp(16).toFloat() }
        setOnClickListener { f() }
    }
    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        Notif.channels(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(20), dp(48), dp(20), dp(16)) }
        root.addView(tv("Hari Ini", 28f, fg, true))
        val et = EditText(this).apply {
            hint = "Ceritakan jadwal, mis. besok jam 7 olahraga, jam 9 kuliah"
            setTextColor(fg); setHintTextColor(mu); textSize = 14f
        }
        root.addView(et, lp(12))
        root.addView(btn("Susun jadwal (Asisten)") { preview(et.text.toString()); et.setText("") }, lp(4))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val sv = ScrollView(this).apply { addView(list) }
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(12) })
        root.addView(btn("+ Tambah kegiatan") { add() }, lp(8))
        setContentView(root)
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        list.removeAllViews()
        val all = Store.all(this).sortedWith(compareBy<Item>({ it.hour }, { it.minute }))
        if (all.isEmpty()) list.addView(tv("Belum ada kegiatan. Tambahkan lewat Asisten atau tombol di bawah.", 14f, mu))
        all.forEach { x ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = box(0x14FFFFFF, 16); setPadding(dp(14), dp(12), dp(14), dp(12))
            }
            row.addView(tv("%02d.%02d".format(x.hour, x.minute), 16f, fg, true).apply { minWidth = dp(64) })
            val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            mid.addView(tv(x.title, 16f, fg, true))
            mid.addView(tv((if (x.alarm) "Alarm" else "Pengingat") + " - " + (if (x.days == 0) "sekali" else "harian"), 12f, mu))
            row.addView(mid, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(Switch(this).apply { isChecked = x.on; setOnCheckedChangeListener { _, v -> upd(x.copy(on = v)) } })
            row.setOnLongClickListener {
                AlertDialog.Builder(this).setMessage("Hapus kegiatan ini?").setPositiveButton("Hapus") { _, _ -> del(x) }.setNegativeButton("Batal", null).show()
                true
            }
            list.addView(row, lp(8))
        }
    }

    private fun upd(x: Item) { Store.save(this, Store.all(this).map { if (it.id == x.id) x else it }); Sched.set(this, x) }
    private fun del(x: Item) { Store.save(this, Store.all(this).filter { it.id != x.id }); Sched.cancel(this, x.id); refresh() }
    private fun put(x: Item) { Store.save(this, Store.all(this) + x); Sched.set(this, x) }

    private fun add() {
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val t = EditText(this).apply { hint = "Nama kegiatan" }
        val tp = TimePicker(this).apply { setIs24HourView(true) }
        val al = CheckBox(this).apply { text = "Alarm keras (bukan sekadar pengingat)"; isChecked = true }
        val dy = CheckBox(this).apply { text = "Ulangi setiap hari" }
        val views: List<View> = listOf(t, tp, al, dy)
        views.forEach { l.addView(it) }
        AlertDialog.Builder(this).setTitle("Kegiatan baru").setView(ScrollView(this).apply { addView(l) })
            .setPositiveButton("Simpan") { _, _ ->
                if (t.text.isNotBlank()) {
                    put(Item(System.currentTimeMillis() % 1_000_000_000L, t.text.toString().trim(), tp.hour, tp.minute, if (dy.isChecked) 127 else 0, 0L, al.isChecked, true))
                    refresh()
                }
            }.setNegativeButton("Batal", null).show()
    }

    private fun preview(s: String) {
        val xs = Parser.parse(s)
        if (xs.isEmpty()) {
            AlertDialog.Builder(this).setMessage("Belum ada jam yang terbaca. Contoh: besok jam 7 olahraga, jam 9 kuliah").setPositiveButton("OK", null).show()
            return
        }
        val m = xs.joinToString("\n") { "%02d.%02d  %s".format(it.hour, it.minute, it.title) }
        AlertDialog.Builder(this).setTitle("Draf jadwal").setMessage(m)
            .setPositiveButton("Setujui dan pasang alarm") { _, _ -> xs.forEach { put(it) }; refresh() }
            .setNegativeButton("Batal", null).show()
    }
}
